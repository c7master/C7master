using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>


#ifndef COMMONSITEFINDER_H 
#define COMMONSITEFINDER_H
#include "CommonSiteFinder.h"
#endif


#ifndef ENUMERATER_H
#define ENUMERATER_H
#include "EnumerateSeq.h"
#endif

#ifndef SEEDOCTAMER_H
#define SEEDOCTAMER_H
#include "SeedOctamer.h"
#endif

#ifndef ASSEMBLESI_H
#define ASSEMBLESI_H
#include "AssembleSi.h"
#endif

#ifndef ALIGNASSEMBLED_H
#define ALIGNASSEMBLED_H
#include "AlignAssembled.h"
#endif

#ifndef SCORESELECTOR_H
#define SCORESELECTOR_H
#include "ScoreSelector.h"
#endif



//don't forget to construct a path for the output folder for all the output files that will be created.
class FileWriter {
public:
	void storeCommonSeeds(string file_name1, vector<common_seed_info> common_seeds);
	void storeOctamers(string file_name2, vector<string> octamers);
	void storeSeedOctamers(string file_name3, vector<seed_octamer>);
	void storeHexamerScores(string file_name4, vector<seed_site_score> seed_scores_LR);
	void printOctamerScores(string file_name5, vector<seed_gene_site_score> seedoctamer_scores);
	void printSiRNAtargets(string file_name6, vector<si_target_info> siDesigns);
	void saveAlignAll (string file_7, vector<siRNA_target_align> align_results);
	void saveAlignAll_excel_tablimit (string outfile_8, vector<siRNA_target_align> align_results);
	void saveHits(string outfile_9, vector<caltarget> hitlist);

};