using namespace std;
#include <string>
class Reverser {
public:	
	string revCompDNA;
	string get_reverse(string DNA_reverse);
};