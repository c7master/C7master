using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

//need to decide the output data structure here.
//use stirng::find function to find substring in a given string
class BCprofiler{
public:
	
};
