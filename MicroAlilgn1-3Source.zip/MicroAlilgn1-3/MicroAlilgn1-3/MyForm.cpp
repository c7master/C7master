#include "MyForm.h"

using namespace MicroAlign;
using namespace std;
using namespace System;
using namespace System::Windows::Forms;
using namespace System::Runtime::InteropServices; // for MarshalString methods

string guide_RNA, target_RNA;
string outputFolderPath;
vector<fasta_sequence> AllsiRNASeqList, AllTargetSeqList; //a list of all fasta sequences with sequence names
vector<slidingWin_seqlist> all_subseq_list;
string outfile_name1, MA_outfile; 

void exec_program();

[STAThread]
void Main(array<String^>^ args)
{
    Application::EnableVisualStyles();
    Application::SetCompatibleTextRenderingDefault(false);
	MicroAlign::MyForm myForm;        //NameOfProject::NameOfForm instanceOfForm;
    Application::Run(%myForm);
}

//MarshalString to interface between managed and unmanaged code. 
//This one is for string convertions.
void MarshalString ( String ^ s, string& os ) {
   using namespace Runtime::InteropServices;
   const char* chars = 
      (const char*)(Marshal::StringToHGlobalAnsi(s)).ToPointer();
   os = chars;
   Marshal::FreeHGlobal(IntPtr((void*)chars));
}


System::Void MyForm::button2_Click(System::Object^  sender, System::EventArgs^  e){
	FolderBrowserDialog^ fbd = gcnew FolderBrowserDialog();
	System::Windows::Forms::DialogResult result = fbd->ShowDialog();
      if ( result == ::DialogResult::OK )
      {
		  textBox2->Text = fbd->SelectedPath;
	  }

	  //pass the path as standard code string
	  System::String^ OutputFolderName = gcnew String(textBox2->Text);
	  string std_OutputFolder = "";

	  //replace backwars slashes in path name with forward ones as in Windows
	  System::String^ Result = OutputFolderName->Replace('\\', '/'); 
 
	  //marshal a System string to standard string
	  MarshalString(Result, std_OutputFolder);
	  outputFolderPath = std_OutputFolder;
}

 System::Void MyForm::button3_Click(System::Object^  sender, System::EventArgs^  e){

	System::String^ inputSeq1 = gcnew String(textBox1->Text);
	MarshalString(inputSeq1, guide_RNA);
		
	cout<<guide_RNA<<endl;			
			
	System::String^ inputSeq2 = gcnew String(textBox3->Text);
	MarshalString(inputSeq2, target_RNA);
		
	cout<<target_RNA<<endl;	

	outfile_name1 = outputFolderPath + "/MA_results.txt";

	exec_program();
}

/*********************AmiFinder 1.0 exec_program****/
 void exec_program(){

	Aligner ali;
	alignment_config alignment_result;
	aligned_pair_info curr_pair_result;

    /*****modified code here to feed the aligner with only at most 21 nt of the target site sequence****/
	string tar_RNA;
    int tar_len = target_RNA.length();
	if (tar_len>=21){
		tar_RNA = target_RNA.substr(target_RNA.length()-21,21);
	}
	else tar_RNA = target_RNA;
    /************************/
	alignment_result = ali.aligne2seq(tar_RNA, guide_RNA);
	curr_pair_result.pair_result = alignment_result;
	
	ofstream myfile;
	myfile.open(outfile_name1);

		myfile<<curr_pair_result.pair_result.cons_query<<endl;
		myfile<<curr_pair_result.pair_result.match_symbols<<endl;
		myfile<<curr_pair_result.pair_result.cons_subject<<endl;
	//	myfile<<curr_pair_result.pair_result.match_score<<endl;
		myfile<<"miScore "<<curr_pair_result.pair_result.miScore<<endl;

	myfile.close();

	cout<<curr_pair_result.pair_result.cons_query<<endl;
	cout<<curr_pair_result.pair_result.match_symbols<<endl;
	cout<<curr_pair_result.pair_result.cons_subject<<endl;
//	cout<<curr_pair_result.pair_result.match_score<<endl;
	cout<<"miScore: "<<curr_pair_result.pair_result.miScore<<endl;

	cout<<"Program execution finished!"<<endl;

}//exec_program