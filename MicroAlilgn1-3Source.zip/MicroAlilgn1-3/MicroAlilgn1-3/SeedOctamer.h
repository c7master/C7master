using namespace std;

#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>

#ifndef COMMONSITEFINDER_H 
#define COMMONSITEFINDER_H
#include "CommonSiteFinder.h"
#endif

#ifndef COMPLEMENTER_H
#define COMPLEMENTER_H
#include "Complementer.h"
#endif

#ifndef ENUMERATER_H
#define ENUMERATER_H
#include "EnumerateSeq.h"
#endif

/*
*/
struct seed_octamer {
	string seedseq;
	vector <string> octamerList;
};

struct seed_nmer{
	string seedseq;
	vector <string> nmerList;
//	vector <int> scoreList;
};

struct seed_left_right {//to store the left and right 6-mers that have at least one 3mer match with target 6mer
	string seed_seq;
	vector<string> left;
	vector<string> right;
};

/**********The following 3 structs are used to evaluate a hexamer's 3-mer match score on each target site************/
/******
Structure outline: For each seed, there are two lists of 6-mers, left and right half of the octamer site. 
For each 6-mer, there is a list of genes upon which the 6-mer targets.
In each gene, there is a list of target sites that the 6-mer has at least one 3mer match. The number of matches is
stored as the score, while the sequence and the start position of the site is stored along with the score.
*****/
struct target_hex_score{
		string target_substring;
		int pos;
		int score;
};

struct geneSiteScore {
	string gene_name;
	vector <target_hex_score> site_scores;
};

struct hexamerGeneScore {
	string hexamer;
	vector <geneSiteScore> gene_scores;
};

struct seed_site_score {
	string seed_seq;
	vector<hexamerGeneScore> left_hex_site_scores;
	vector<hexamerGeneScore> right_hex_site_scores;
};

/**********************data structures for octamer scoring***********/
struct target_score{
		string target_seq;
		string target_substring;
		int pos;
		int score;
};

struct gene8merSiteScore {
	string gene_name;
	vector <target_score> site_scores;
};

struct GeneScore {
	string hexamer;
	vector <gene8merSiteScore> genesite_scores;
};

struct seed_gene_site_score {
	string seed_seq;
	vector<GeneScore> seedgenesite_scores;
};

/****************************/

/********Data structure for hit site sequence stats************/

//The intermediate data structure for further processig of the sequence information

struct hitSitesInfo { 
	string nmer; //the hexamer that is selected to match all the target sites
	string target_seq;
	int pos;
	int score;
};
/******for the output of seed nmer bulge tail concensus***********************/

struct nmer_bulge_tail {
	string nmer;
	string bulge;
	string tail;
	vector<string> gene_names;
	vector<int> target_positions;
	vector<string> targets;
	vector<int> trimatch_scores;
};

struct seed_bulge_tail {
	string seed_seq;
	vector<nmer_bulge_tail> bulgetails;
};



/*******************************/

struct target_seq_info{ //the output data structure of the central bulge and the tail sequences by substring of the target
	string gene_name;
	string central_bulge; //nt 9 and 10
	string tail;//nt 17-21
	int target_pos;
	string target_seq;
	int score;
};

struct nmer_concensus{ //an n-mer and a list of all its possible central bulges and tails
	string nmer;
	vector<target_seq_info> concensus_seq_table;
};

struct seed_nmer_info{ //for each seed, the above data structure exists
	string seed_seq;
	vector<nmer_concensus> nmer_concensus_table;
};


/******************************/


//vector <seed_octamer> seedoctable;
class SeedOctamer{
public:
	//member variable that stores the hexamers. Octamers are returned by listNmer function
	vector<seed_left_right> seed_hexamers;

	/************new general functions implemented***************/
	vector <seed_octamer> listNmers (vector<common_seed_info> input_table, int N);
	vector<seed_site_score> oligoScoreTarget(vector<seed_left_right>, vector<common_seed_info>);//score each hexamer with 6mer target site by 3mer matching
	vector<string> make_nmer_sitelist(siteinfo gene_sites, int start, int len);	
	vector<string> update_n_mers(vector<string>, vector<string>);
	int MNxmer_match(int x, string M_mer, string N_mer); //returns 1 if there is at least 1 3mer match
	int MNxmer_tiling_oneside(int x, string M_mer, string N_mer);
	int MNxmer_score(int x, string M_mer, string N_mer);//returns the number of matches as the score.
	vector<seed_gene_site_score> NmerScoreTarget(vector<seed_octamer> seedOctamers_table, vector<common_seed_info> common_seeds);
	vector<GeneScore> produce_nmerScores(vector<string> leftorright, vector<siteinfo> seedSiteInfotable);

	/********************functions for scoring 2 overlaping n-mers against the target site.*******************************/
	vector<string> construct_8mer_table(vector<string> left, vector<string> right);
	string mergeLeftRight(string left_string, string right_string, int overlap);
	void set_slr_table(vector<seed_left_right>);
	vector <seed_octamer> listNmersLR (vector<common_seed_info> input_table, vector<string> Nmers);
	vector<hexamerGeneScore> produce_moiety_6merScores(vector<string> leftorright, vector<siteinfo> seedSiteInfotable, string half);
	


	/***************functions for hit site sequnce stats for the concensus sequence design***************************/
	vector<seed_nmer_info> list_bulge_tail(vector<seed_gene_site_score> seed_nmer_gene_score_list);
	//this function takes the viable common seeds with n-mer hit site scores, retreive all the target site sequences from the common_seed table;
	//A concensus sequence for the bulge and tail will be generated from all the hit sites (score >=1)

	vector<seed_bulge_tail> seed_nmer_bulge_tail_concensus(vector<seed_nmer_info>);

	string compute_concensus(vector<string> input_strings, int position); //given a vector of strings, compute the most frequence occurring nt at a given position.
	string compute_concensus_string(vector<string> seqs);
};

