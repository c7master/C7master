using namespace std;

#include "CommonSiteFinder.h"
int seed_len = 7; //seed region length
int seed_start = 2; //seed starting nucleotide position in the siRNA from it 5', or from the 3' of the mRNA.

vector <common_seed_info> CommonSiteFinder::find_common_seed_sites(vector <slidingWin_seqlist> slidesitelist){
	//1. confirm there are >= 2 entries in the slidesitelist
	//2. construct the common seed site list by comparing 1st and 2nd gene
	//3. start loop that compares the new common seed site with every gene left in the list
	//4. test output, return the common list.
	vector<string>	seedlist,
					//holds only a string list for common seeds at every step, 
					//redundancy will be removed at every step.
					//this list will be used as query to generate a complete output (gene_id, pos, and site_sequence).
					
					temp_initial_list; //holds the temp list of first 2 genes, for redundant removal. 
	
	if (slidesitelist.size() < 2){
		error_message();
	}
	else {
		//
		temp_initial_list = make_2gene_seedlist(slidesitelist);
		if (slidesitelist.size() > 2){	
		temp_initial_list = make_moregene_seedlist(slidesitelist, temp_initial_list);
		
		}//if there are more than 2 genes in the list
		seedlist = remove_polyA(temp_initial_list); //remove polyA seeds (with 6As), reassign the non-redundant list to seedlist

	}//else there are no less than 2 entries in the list

	vector <common_seed_info> common_seed_list;//stores all common seed sites among listed genes
	common_seed_list = construct_info_table(seedlist, slidesitelist);
	return common_seed_list;

}//find_common_seed_sites

int CommonSiteFinder::get_window_size(vector <slidingWin_seqlist> slidesitelist){
	int window_size = slidesitelist[0].SlidingSeqList[0].size();
	return window_size;
}

int CommonSiteFinder::get_start_pos(vector <slidingWin_seqlist> slidesitelist){
	int window_size = slidesitelist[0].SlidingSeqList[0].size();
	int start_pos = window_size - (seed_len + seed_start -1);
	return start_pos;
}

void CommonSiteFinder::error_message(){
	cout<<"At least two gene sequences are needed."<<endl;
}

vector <string> CommonSiteFinder::remove_redundant (vector <string> input_vector){
	//This function uses "sort" and "erase" combination to remove redundant entries in a vector.
	vector <string> output_vector;
	sort(input_vector.begin(), input_vector.end());
	input_vector.erase(unique(input_vector.begin(), input_vector.end()), input_vector.end());
	output_vector = input_vector;
	return output_vector;
}

vector<string> CommonSiteFinder::make_2gene_seedlist(vector <slidingWin_seqlist> slidesitelist){

	int window_size = get_window_size(slidesitelist);
	int seed_start = get_start_pos(slidesitelist); 

	//seed start position in the target mRNA, 
	//starting at the -8 position from the 3'end of the sliding windowed mRNA 
	
	//int seed_len = 7; //seed region length
	string seq1_name, seq2_name;
	vector<string> seq1_sliding_list, //holds the tiling sequences of the 1st gene
				   seq2_sliding_list; //holds the tiling sequences of the 2nd gene
	string subseq1_seed, subseq2_seed; //holds the subsequences of the seed region of the tiling sequence
	vector<string>	seedlist,
					temp_initial_list; 
		seq1_sliding_list = slidesitelist[0].SlidingSeqList;
		seq2_sliding_list = slidesitelist[1].SlidingSeqList;

		//hold the 1st and the 2nd gene sequences in a temporary vectors.
		for (vector<string>::size_type i = 0; i<seq1_sliding_list.size(); i++){
			subseq1_seed = seq1_sliding_list[i].substr(seed_start, seed_len);
			for (vector<string>::size_type j = 0; j < seq2_sliding_list.size(); j++){
				subseq2_seed = seq2_sliding_list[j].substr(seed_start, seed_len);
				if (subseq1_seed.compare(subseq2_seed)==0) {//if the seeds are the same, save this entry
				//	cout<<subseq1_seed<<'\t'<<subseq2_seed<<endl;
					seedlist.push_back(subseq2_seed); //save the common seed into temp_seedlist	
				}//if
			}//for j
		}//for i, this generates the first temp_seedlist by comparing first 2 gene sequences.
		temp_initial_list = remove_redundant(seedlist);//remove redundant seeds in the temp table
	//	cout<<"size of temp_intial_list is "<<temp_initial_list.size()<<endl;
		//seedlist = temp_initial_list; //reassign the non-redundant list to seedlist
		
		return temp_initial_list;
}

vector<string> CommonSiteFinder::make_moregene_seedlist(vector <slidingWin_seqlist> slidesitelist, vector<string> temp_initial_list){
			int window_size = get_window_size(slidesitelist);
			int seed_start = get_start_pos(slidesitelist); 

			//	cout<<slidesitelist.size();
			vector<string> query_seeds = temp_initial_list;
			//gets declared right ouside of the callig loop

			vector<string>	current_sliding_list;
					//points to the current gene sequence when going through the tiling sequences of all genes

			for (vector <slidingWin_seqlist>::size_type i = 2; i <slidesitelist.size();i++)
			{//for every gene in the list starting from the 3rd gene
				current_sliding_list = slidesitelist[i].SlidingSeqList;
				//look at one gene at a time. Update the common seedlist after

				vector <string> temp_common_seeds;
				//holds the temporary common seeds as going through one gene at a time
				//This will be used to update the common seed list table after each loop.
				//!!!IMPORTANT!!! As a loop variable that gets updated at every incrment, it has to be
				//declared right outside of the calling loop so that it gets reset every time for update.
				//Otherwise it will keep the same value from the previous cycle.

				for (vector<string>::size_type j = 0; j < query_seeds.size(); j++)
					{//the seedlist is updated after searching each gene
						string current_query_seed = query_seeds[j];
					for (vector<string>::size_type k = 0; k < current_sliding_list.size(); k++)
						{//for each sliding window sequence, check if it's the same as the current seedlist entry
						//cout<<"k = "<<k<<endl;
						string current_window_seed = current_sliding_list[k].substr(seed_start, seed_len);
						if (current_query_seed.compare(current_window_seed)==0) 
						{
						//if the seeds are the same, save this entry
						temp_common_seeds.push_back(current_query_seed); //add this entry to the tempoarary seed list
					//	break;//this seed is found in the new sequence, save it to a new temp list and break out of loop of this seed, go for next seed
						}//if it is a common seed
					}//for k (each tiling sequence in the site list)
					//no need to check redundancy becauase temp_common_seeds is a subset of original query_seeds, which is already redundancy-free.
				
				}//  for j (each seed in the common seed list)
				query_seeds = remove_redundant(temp_common_seeds);//pass value to query_seeds, temp_common_seeds gets reset at the beginning of the loop
	//			cout<<query_seeds.size()<<endl;


				//after all the seeds in the query list are checked with current gene, 
				//update the query seeds and move on to the next gene
			}// for i (each entry in the gene list)
		//	temp_common_seeds = query_seeds;
		temp_initial_list = query_seeds; //reset the value of temp_initial_list
		return temp_initial_list;
}

vector<common_seed_info> CommonSiteFinder::construct_info_table(vector<string> seedlist, vector <slidingWin_seqlist> slidesitelist){

	/*****************Generate a common seed list, strings of 7 nt only. ************************/
/*********The following is the core code here that stores matchning results in a data structure*********/
	//1. make an entry in the output vector<common_seed_info> common_seed_list
	//for every temp_seelist by pushback seed sequence into the vector
	//2. retreive other information regarding this seed into the vector.

	int window_size = get_window_size(slidesitelist);
	int seed_start = get_start_pos(slidesitelist);  

	vector <common_seed_info> common_seed_list;//stores all common seed sites among listed genes
	for (vector<string>::size_type i = 0; i < seedlist.size(); i++){
		common_seed_info temp_info;
		temp_info.seed_sequence = seedlist[i];
		common_seed_list.push_back(temp_info);
//		cout<<seedlist[i]<<endl;
	}
	//The above code pushes back seed sequences only, make the output vector of desired sized.

	site_in_gene current_site; //smallest struct of {int, string}
	siteinfo current_site_per_gene; //middle struct2 of {gene_name, vector of struct1}

	//The following code will store relavant information into the output vector
	//one at a time since the sizes are already known. This is done by using the 
	//seed_list and loop up the sliding_window_site table to retreive site information.

	for (vector<string>::size_type i = 0; i < seedlist.size(); i++){//for each common seed
		for (vector <slidingWin_seqlist>::size_type j = 0; j < slidesitelist.size(); j++)
		{//for each gene
			current_site_per_gene.gene_id = slidesitelist[j].seq_name;
			common_seed_list[i].site_list.push_back(current_site_per_gene);//make an entry for the current gene in the list of seed_sites listed by gene
			for (vector<string>::size_type k = 0; k < slidesitelist[j].SlidingSeqList.size(); k++)
			{//for each sliding window sequence
				if (seedlist[i].compare(slidesitelist[j].SlidingSeqList[k].substr(seed_start,seed_len))==0)
				{//if seedlist entry matches in seed of the sliding window sequence
					//retreive information of all satisfactory sites in the current gene
					current_site.start_pos = k;
					current_site.site_sequence = slidesitelist[j].SlidingSeqList[k];
					common_seed_list[i].site_list[j].gene_site_table.push_back(current_site);
					//save this temp_site information (gene id, start_pos, and site seq)
				}//if the seed sequence is found in the site region
			}//for each tiling sequence in the list
		}// for each gene listed in the tiling sequences list
	}//for each common seed sequence, make an entry in the output data structure
/*************************************end of core code**************************************************/
	return common_seed_list;
}

vector<string> CommonSiteFinder::remove_polyA(vector<string> seedlist){
	//declare output
	vector<string> output_list;

	//prepare input
	string polyA = "AAAAAA";

	for(int i = 0; i<seedlist.size(); i++){
		
		if (seedlist[i].find(polyA)!= string::npos){//if a polA of 6As is found as asubstring anywhere
			//do nothing
		}
		else{//o.w., copy it to the output vetor
			output_list.push_back(seedlist[i]);
		}//else
	}//for

	return output_list;
}

