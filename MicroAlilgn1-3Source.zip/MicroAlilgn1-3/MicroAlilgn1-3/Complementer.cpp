
#include "Complementer.h"

string Complementer::get_complement (string DNA_comple){
   		string complementDNA = "";
   		int seq_length = DNA_comple.length();
   		for (int i = 0; i < seq_length; i++){	
   			char current = DNA_comple.at(i);
   			switch (current){
   				case 'A':
   					complementDNA = complementDNA.append("T");
   				break;
   				case 'a': 
   					complementDNA = complementDNA.append("t");
   				break;
   				case 'T': 
   					complementDNA = complementDNA.append("A"); 
   				break;
   				case 't': 
   					complementDNA = complementDNA.append("a");
   				break;
   				case 'G': 
   					complementDNA = complementDNA.append("C");
   				break;
   				case 'g': 
   					complementDNA = complementDNA.append("c");
   				break;
   				case 'C': 
   					complementDNA = complementDNA.append("G");
   				break;
   				case 'c': 
   					complementDNA = complementDNA.append("g");
   				break;					
   			
   			} //switch		
   		} //for
   	//	System.out.println(complementDNA);
   		return complementDNA;
    }// get_complement

int Complementer::isWobbleComp (string str1, string str2){//returns 1 if the sequences are Wobble complement; 0 otherwise.
	int res;
	if (str1.size() != str2.size()){
		cout<<"Wobble: The two string must have the same length. Please check the input sequences."<<endl;
	}
	else {
		for (int i = 0; i < str1.size(); i++){
			char char1 = str1.at(i);
			char char2 = str2.at(i);

			if ((char1 == 'A')&&(char2=='T')){
				res = 1;
			}//if A-T
			else if ((char1 == 'C')&&(char2=='G')){
				res = 1;
			}//if C-G
			else if ((char1 == 'G') && ( (char2=='C') || (char2=='T'))){
				res = 1;
			}//if G-CU
			else if ((char1 == 'T')&&((char2=='A')||(char2 == 'G'))){
				res = 1;
			}//of T-AG
			else{
			res = 0;
			break;
			}//not a match

			if (res == 0) {//if any nucleotide doesn't pair, break out of loop and stop.
				break;
			}
		}//for every char in the sequence
	}//else, both strings are of equal length
	return res;
}

int Complementer::isWatsonCrick (string str1, string str2){//returns 1 if the sequences are Wobble complement; 0 otherwise.
	int res;
	if (str1.size() != str2.size()){
		cout<<"The two string must have the same length. Please check the input sequences."<<endl;
	}
	else {
		for (int i = 0; i < str1.size(); i++){
			char char1 = str1.at(i);
			char char2 = str2.at(i);

			if ((char1 == 'A')&&(char2=='T')){
				res = 1;
			}//if A-T
			else if ((char1 == 'C')&&(char2=='G')){
				res = 1;
			}//if C-G
			else if ((char1 == 'G') && (char2=='C')){
				res = 1;
			}//if G-CU
			else if ((char1 == 'T')&&(char2=='A')){
				res = 1;
			}//of T-AG
			else{
			res = 0;
			break;
			}//not a match

			if (res == 0) {//if any nucleotide doesn't pair, break out of loop and stop.
				break;
			}
		}//for every char in the sequence
	}//else, both strings are of equal length
	return res;
}