using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>


#ifndef COMMONSITEFINDER_H 
#define COMMONSITEFINDER_H
#include "CommonSiteFinder.h"
#endif


#ifndef ENUMERATER_H
#define ENUMERATER_H
#include "EnumerateSeq.h"
#endif

#ifndef SEEDOCTAMER_H
#define SEEDOCTAMER_H
#include "SeedOctamer.h"
#endif


/**********************data structures for octamer scoring***********/
struct gene_target_score{
		string gene_name;
		string targetseq;
		int pos;
		int score;
};


struct GeneScore {
	string hexamer;
	vector <gene8merSiteScore> genesite_scores;
};

struct seed_gene_site_score {
	string seed_seq;
	vector<GeneScore> seedgenesite_scores;
};

/******************************/


//vector <seed_octamer> seedoctable;
class HitSiteSeq{
public:




};