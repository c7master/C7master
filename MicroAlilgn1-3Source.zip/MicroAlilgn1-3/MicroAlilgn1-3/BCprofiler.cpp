using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>


/****find if there is a continuous stretch of nucleotides match in the B and C region: nt 11-19********

string str ("There are two needles in this haystack.");
string str2 ("needle");

if (str.find(str2) != string::npos) {
//.. found.
} 






*******************************************************************************************************/