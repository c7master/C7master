using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include "Filelist_maker.h"

	
vector<string> Filelist_maker::generate_filelist(string file_of_filelist){

	string word;
	ifstream infile (file_of_filelist);
	vector<string> file_list;

	if (infile.is_open())
	{
		while (infile.good())
		{
			getline (infile, word);
			if (word.length() > 0){
				file_list.push_back(word);
			}//if word length > 0
		}//while
	infile.close();
	}//if
	else 
		//can't open file error message
		cout << "Unable to open gene file"<<endl; 

	return file_list;
}

//takes a file that contain a list of file names that contain sequences in fasta format
//returns a vector of structs of sequences name and the actual sequence
vector<fasta_sequence> Filelist_maker::multiFile_seqlist(string file_name){
	vector<string> genefilenames;
	//Filelist_maker maker;
	genefilenames = generate_filelist(file_name);
	vector <fasta_sequence> All_sequences;

	//instantiated outside any loop, 
	// it can hold all the sequences from multiple files as looping through all files.
	Fasta_parser file1parser;	

	//go through the file list, open each file and parse each gene sequence into the list
	for (vector<string>::size_type i = 0; i < genefilenames.size(); i++){

		//hold all sequences in the current file in a temporary list
		vector<fasta_sequence> temp_list = file1parser.fasta2list(genefilenames[i]);

		//append current fasta sequences to the exisitig list
		All_sequences.insert(All_sequences.end(), temp_list.begin(),temp_list.end());
		
		}//for each file name in the file list
	return All_sequences;
}
