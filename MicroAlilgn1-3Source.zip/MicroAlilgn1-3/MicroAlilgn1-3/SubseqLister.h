using namespace std;
using namespace std;
#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>

#ifndef FASTA_PARSER_H
#define FASTA_PARSER_H
#include "Fasta_parser.h"
#endif
struct slidingWin_seqlist{
	string seq_name;
	vector<string> SlidingSeqList;
};


class SubseqLister{
public:
	vector <slidingWin_seqlist> make_site_list(vector<fasta_sequence> seqlist);
};

