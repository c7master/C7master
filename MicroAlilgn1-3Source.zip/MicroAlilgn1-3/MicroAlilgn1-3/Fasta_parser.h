using namespace std;

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>


struct fasta_sequence {
	string sequence_name;
	string sequence;
};


class Fasta_parser{
public:
	vector<fasta_sequence> fasta2list(string filename);
};