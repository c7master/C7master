/*
This program reads a FASTA file (without line numbers and spaces) and parse the DNA seqence 
into a single string or an array of chars. Later, searches of oligomers can be performed on
the string. 
This program searches for the multi-targeting shRNA target sites given two sequence files

Target site rules:
Chi et al. Nature 2009 (Darnell), 37% sites in coding region, 63% of sites are in 3'UTR;
In 3'UTR, sites peak at ~50 nt downstream of STOP codon;
sites peak at ~70 nt upstream of the poly(A) signal.

Target site should be 22 nt total, but designed siRNA 
only involves 21 nt, the 3'-most end nucleotide is added by full complementation to the target site.

The design criteria are the following:
 A/U at pos. 1;
 40-80% A/U;
 >50% A/U in pos. 1-14;
 (A/U% 1-14) / (A/U% 15-22)>1;
 No A at pos. 20;
 A/U at pos. 13 OR U at pos. 14;
 no 'AAAAAA'(6X) or 'TTTTT'(5X) or 'CCCC'(4X) or 'GGGG'(4X);

 The output of the program will be two lists. The first list consists of seeds

 Goals of the program:
 1. generate a list of target sites with their positions in the gene given a seed sequence
 2. Given a gene, generate a non-redundant list of seeds of desired length with their positions in the gene, 
	as well as a list of 22 nt target sites (sequences and postions in the gene) of each seed.
 3. Given two genes, generate a list of common seeds of desired length, and a list of target sites of each
	seed in each gene.
 
 Twoo modesof the program:
 mode1: query a target site or a siRNA sequence in a gene/gene region
 mode2: commom seeds of two genes

 Data structure of the results of two gene common seed match: Vector of struct; the struct contains:
	{seed_id_num, 
	seed_seq, 
	seed_multiplicity;
	gene_name, 
	gene_seq_id, 
	genbank_id,
	seed_pos, 
	site_seq, 
	site_start, 
	site_end,
	}.
	Each entry in the output table should contain these information. Each entry in the table corresponds 
	to a 'hit' of the seed in the gene sequence. For a seed, it will have matches in both genes. In each 
	gene, there could be multiple 'hits'. But each entry of the output table only contains the information
	for that particular hit.

ways to get inputs for the program:
1. ask the user to enter the sequence of the siRNA or the target site, as well as the file name of the gene	
	sequence. Then we run in mode 1.
2. Ask the user for the file names of the two genes, and the size of the seed. For testing, the file names 
	are written in a text file
	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchIn/mode2_in_file.txt"
	The two file names with their full paths are:
	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchIn/HIV-1_in_pNL.txt"
	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Gene_sequences_NewFolder/PCAF/PCAF_mRNA.txt"


outputs generated: 
Mode 1: Output is successful! It lists the target sites of the input seed sequence in the command prompt, and 
	it saves the output in an indexed format in output file
	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchOut/Sitelist.txt"
	
Mode 2:
1. Console output: array format, each seed, a table of sequence, gene name, site postions, site sequence; 
	high redundancy is expected. 
2. Output file, pivot table format of the common seeds and their matching sites in different genes.
	!!! This is not done yet. The program still doesn't write outputs to a file.
	declare a different output file:
	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchOut/Mode2out.txt"
!!! need to make subseq_search work well with mode 2, where a list of common seeds will examined one by one in both
genes to list the target sites. In other words, the subseq_search method must be changed to a more general form.


***************/

using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>
//global variables definitions
string input_batch_file = 
//		"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchIn/mode2_in_file_rab6a.txt";
	"C:/Users/Yifei/Documents/Lab/Compute/SeedSearchIn/mode2_in_file.txt";

int site_len = 21;	//define shRNA target site length as a global variable
//int subseq_len = 0; //the length of the subsequence
struct Mode2_parameters{
	int seed_length;
	int site_length;
	string gene1_filename;
	string gene2_filenmae;
	//string all_genes_file;
}; //the return type of function aske_user_parameters();

//This is originally for common seed information, but can be used to store any common subsequence information
struct seed_info{
	int seed_id_num;
	string seed_seq;
	int gene_id;//the index number of the gene. Should be the same as the
	int seed_multiplicity;
	int seed_pos;//the position of the subsequence in the gene of interest.
	string site_seq;
}; //define the output struct of the mode2 multi target seed search.

//The following 2-D vector holds all subsequences that match the criteria of search, including the profile searches.
//This table contain only sequence information, and a table that contain the postion and copy number information for the ouput
//will be built using this table later: the vector<vector<match_seq>>, where match_seq is a struct that contains more info. 
//This is a 2-pass search algorithm.
vector<vector<string>> match_seq_table;

//This structure holds the information of each subsequence found to match the search criteria.
//A specialized data structure is necessary. match_seq is the structure that holds all information
//of the entrie that satisfy the criteria. 
struct match_seq { 
	string sequence;
	string gene_name;
	int position;
};

vector <vector <match_seq>> common_table;//this is the table that holds all outputs of the program

vector <string> common_entries, common_entries1, common_entries2;

string get_subseq();
//prompts the user to enter the subsequence for the search, returns the subsequence as a string.

vector<int> subseq_search(string, string); 
//finds the subsequence and returns a list (a vector) of the start positions of the subseq.

string get_search_area(string);		
//store the whole target mRNA sequence in one string from a sequence file name 

vector<string> get_shRNA_sites(vector<int>,int, int, string);	
//store the target site sequences in an array

void save_sitelist2file(vector<int>, vector<string>, string);

void save_mode2out(string, vector<seed_info>);

string reverse_complement(string); 
//convert the input string to its reverse complement, then return the new string
string get_complement (string);

string get_reverse (string);

int choose_program_mode();


void program_mode_1();
//mode 1: seed search in a FASTA file of the target gene. Query sequence is either
//an shRNA seed or a seed binding site in mRNA

void program_mode_2();
//searh for common seed binding site in two genes

Mode2_parameters ask_user_parameters();
//prompt the user to enter parameters to run the second mode of the program

int get_seed_size();
//ask for the size of the seed binding site, returns to caller ask_suer_parameters();

int get_site_size();
//ask the user for the size of the shRNA that he wishes to design, usually 21 nt.

vector<string> get_gene_files(string);
//asks the user to specify the name and location of the FASTA file of the first gene (cDNA) sequence

string get_commonseed_outfile();
//asks the user to specify the name and location of the output file of mode 2 of the program

vector<string> make_site_list(string, int);
//mkae a list of subsequences of a given length from a FASTA file

vector<string> compare_lists(vector<string>, vector<string>);
//compare two input string vectors and return a string vector of common entries

vector <string> remove_redundant (vector <string>);

int compare_entries (string, string);

void build_match_table(vector<string>, vector<string>);

void build_result_table(vector<string>, vector<string>, vector<vector<string>>, vector<vector<match_seq>>);
//first 3 paramters for the input of the program and the last parameter for saving the output


/*************************************************
int main ()
{
	int exiting = 0;
	char response;
	while (exiting != 1){
		int mode = choose_program_mode();
		if (mode==1){
			program_mode_1();
			cout<<"exiting?"<<endl;
			cin>>response;
			if (response == 'y'){
				exiting = 1;
			}
			else exiting = 0;
		}
		else if (mode ==2){
			program_mode_2();
			cout<<"exiting?"<<endl;
			cin>>response;
			if (response == 'y'){
				exiting = 1;
			}
			else exiting = 0;
			}
		else cout<<"Invalid choice. Exiting program..."<<endl;
	}
	system("pause");
	return 0;
}
*********************************************/


int choose_program_mode(){
	cout<<"Please choose the mode of the program that you wish to run:"<<endl;
	cout<<"1. SeedSearch in mRNA (in DNA sequence format);"<<endl;
	cout<<"2. Common seed binding site search of two mRNA sequences."<<endl;
	cout<<"1 or 2?"<<endl;
	
	//convert cin to an integer;
	string input = "";
	int choice=0;
	while (true) {
	   getline(cin, input);
	   // This code converts from string to number safely.
	stringstream myStream(input);
	if (myStream >> choice)
		 break;
	cout << "Invalid number, please try again" << endl;
	}
	//cout << "You entered: " << myNumber << endl << endl;
	return choice;
}
void program_mode_1(){
	string inputFileName = 
	//	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchIn/HIV-1_in_pNL.txt"; 
	//pNL4-3 sequence file
	"C:/Users/Yifei/Documents/Lab/Gene_sequences/Akt1-1_3UTR_DNA.txt";
	//PCAF sequence file
	//"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Gene_sequences_NewFolder/PCAF/PCAF_3UTR_clear.fasta";
	//PCAF 3'UTR
	//"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/sequencing/results/SeqReq-24036_2012-10-25/326_322.seq"; //test file
	//NOTE: Forward slash / is mandatory for the file path to work.
	//string inputFile2 = "C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchIn/HIV-1_in_pNL.txt"
	
	string outputFileName = "C:/Users/Yifei/Documents/Lab/Compute/SeedSearchOut/Sitelist.txt";

	string search_area_seq, my_target;
	search_area_seq = get_search_area(inputFileName); //stores the total input gene sequence in "search_area_seq"
	my_target = get_subseq(); 

	/**************************
	//This function asks user to choose which type of sequence they want to enter. (shRNA or target) 
	//If an shRNA seed is entered, the program will convert it to rev-comp, then search for binding sites in target;
	//othewise, the program assumes the user entered the binding site sequence in mRNA, 
	//and the input sequence will be used as query.
	

	vector<int> list_seed_indeces = subseq_search(my_target, search_area_seq);
	//save the search results into a vector for a list of the indeces of the seed binding sites

	int si_len = 22;//user defined shRNA binding site length

	vector<string> list_sites = get_shRNA_sites(list_seed_indeces, si_len, my_target.length(), search_area_seq);
	save_sitelist2file(list_seed_indeces, list_sites, outputFileName);

	/***************************
	//test output of the list of target sites
	for (vector<int>::size_type i = 0; i < list_seed_indeces.size(); i++){
			cout << i+1 << '\t' << list_seed_indeces[i] << '\t' << list_sites[i] << endl;
		}
	/***************************/

}
void program_mode_2(){
	
	//this function will ask the user for the size of common seed binding sites, as well as
	//the total length of the binding site, hence the putative shRNA size.

	Mode2_parameters param = ask_user_parameters(); //recall this struct is (seed_size, site_size, gene1file, gene2file)
	
	int window_size = param.seed_length;
	int site_size = param.site_length;
	string gene1file = param.gene1_filename;
	string gene2file = param.gene2_filenmae;
	
	vector <string> gene1_site_list = make_site_list(gene1file, window_size);
	vector <string> gene2_site_list = make_site_list(gene2file, window_size);

	string outputFileName = "C:/Users/Yifei/Documents/Lab/Compute/SeedSearchOut/Mode2out.txt";

	vector <string> common_seeds = compare_lists(gene1_site_list, gene2_site_list);
	//find the seeds or subsequences that two genes have in common

	string gene1_seq = get_search_area(gene1file);
	string gene2_seq = get_search_area(gene2file);

	vector<int> common_substr_index_gene1, common_substr_index_gene2;
	//store the indeces of the common seeds in both genes
	vector<int> site_pos_list;
	int multiplicity = 0;

	//coommon seed list, of seed_info type
	vector <seed_info> cs_list;

	if (common_seeds.size() == 0) {
		cout<<"There is no common subsequence of the length specified."<<endl;
		}
	else {	
		int k = 0;
		for (vector<string>::size_type i = 0; i < common_seeds.size(); i++){//for each common seed in the list	
			vector<string> seed2site_list;
			site_pos_list = subseq_search(common_seeds[i],gene1_seq); //list of seed sites in gene 1
			seed2site_list = get_shRNA_sites(site_pos_list, site_size, window_size, gene1_seq);
			//get shRNA sites in gene 1
			
			common_substr_index_gene1.insert(common_substr_index_gene1.end(), site_pos_list.begin(), site_pos_list.end());
			multiplicity =  site_pos_list.size();
			for (vector<int>::size_type j = 0; j < site_pos_list.size(); j++){
	/***
	struct seed_info{ //8 fields, 0-7.
	int seed_id_num;
	string seed_seq;
	int gene_id;
	int seed_multiplicity;
	int seed_pos; 
	};
	**/
				cout<<"In gene1: "<<common_seeds[i] << " occurs " << multiplicity << " times. "<<" at: "<<site_pos_list[j]<<endl;
				cs_list.push_back(seed_info()); //for every comon seed, create an entry in the struct vector
				cs_list[k].seed_id_num = i + 1;
				cs_list[k].seed_seq = common_seeds[i];
				cs_list[k].gene_id = 1;
				cs_list[k].seed_multiplicity = multiplicity;
				cs_list[k].seed_pos = site_pos_list[j];
				cs_list[k].site_seq = seed2site_list[j];
				k++;
			}// for loop, writes each of the ocurrence of a given seed in a gene to a std output

			site_pos_list = subseq_search(common_seeds[i],gene2_seq); //list of positions of seed sites in gene 2
			//get shRNA_sites in gene 2
			seed2site_list = get_shRNA_sites(site_pos_list, site_size, window_size, gene2_seq);

			common_substr_index_gene2.insert(common_substr_index_gene2.end(), site_pos_list.begin(), site_pos_list.end());
			multiplicity = site_pos_list.size();
			for (vector<int>::size_type j = 0; j < site_pos_list.size(); j++){
				cout<<"In gene2: "<<common_seeds[i] << " occurs " << multiplicity << " times. "<<" at: "<<site_pos_list[j]<<endl;
				cs_list.push_back(seed_info()); //for every comon seed, create an entry in the struct vector
				cs_list[k].seed_id_num = i + 1;
				cs_list[k].seed_seq = common_seeds[i];
				cs_list[k].gene_id = 2;
				cs_list[k].seed_multiplicity = multiplicity;
				cs_list[k].seed_pos = site_pos_list[j];
				cs_list[k].site_seq = seed2site_list[j];
				k++;
			}// for site_pos_list
		}//store all common seed sites' indeces		
	}//else

	//need to store all found information into a vector of struct, then write the vector of struct to the output file.

		/*
		for (vector<string>::size_type j = 0; j < common_substr_index_gene1.size(); j++){
				cout<<"In gene1:"<<endl;
				cout<<common_substr_index_gene1[j]<<endl;
		}//output common seeds	
		
		
		for (vector<string>::size_type j = 0; j < common_substr_index_gene2.size(); j++){
				cout<<"In gene2:"<<endl;
				cout<<common_substr_index_gene2[j]<<endl;
		}
		*/
		/*
		for (vector<string>::size_type i = 0; i < common_seeds.size(); i++){
			cout<<"Seed match sites in gene 1:"<<endl;
			cout<<i+1<<'\t'<<common_seeds[i]<<endl;
		}//output common seeds
		/*/

		/**
		for (vector<string>::size_type i = 0; i < common_seeds.size(); i++){
			common_substr_index_gene2 = subseq_search(common_seeds[i],gene2_seq);
			for (vector<string>::size_type j = 0; i < common_substr_index_gene2.size(); j++){
				cout<<common_substr_index_gene2[j]<<endl;
			}//inner for
		}//outer for
		**/
	save_mode2out(outputFileName, cs_list);
}
vector <string> compare_lists(vector<string> list1,  vector<string> list2){
	//this method should generate a list of entries that both lists have in common, with no redundant entries
	// this is done by sorting the two lists, followed by making a unique list of entries, and remove the redundant
	//entries from them, then compare the two lists for common entries.

	

	vector <string> unique_list1, unique_list2;

	//DELCARE a new data structure that holds the result of pattern matching of multiple genes.
	//USE A VECTOR OF VECTORS OF A STRUCT that holds the sequence and position of the matched sites of a given size


 	unique_list1 = remove_redundant(list1);
	//Use "sort" and "erase" combination to remove redundant entries in a vector
	//sort(list1.begin(),list1.end());
	//list1.erase(unique(list1.begin(), list1.end()), list1.end());
	/****
	for (vector<string>::size_type i = 0; i < list1.size(); i++){
	cout<<i<<'\t'<<list1[i]<<endl;
	}
	**/

	unique_list2 = remove_redundant (list2);
	
	//sort(list2.begin(), list2.end());
	//list2.erase(unique(list2.begin(), list2.end()), list2.end());
/***
	for (vector<string>::size_type i = 0; i < list2.size(); i++){
	cout<<i<<'\t'<<list1[i]<<endl;
	}
	**/

	/**/

//	vector <vector<match_seq>> match_table;
	//THIS IS THE CORE COMPARISON CODE. I SHOULD IMPLEMENT A FUNCTION ABOUT DIFFERENT WAYS OF COMPARING
	for (vector<string>::size_type i = 0; i < unique_list1.size(); i++){
		for (vector<string>::size_type j = 0; j < unique_list2.size(); j++){
	//		if (unique_list1[i].compare(unique_list2[j])==0){ 
				//two entries are the same
			if (compare_entries(unique_list1[i], unique_list2[j]) == 0){	
				//The following statement causes a problem when pattern matching is used rather than exact matching.
				//This resulted when the two entries are not exactly the same, rather, matching in profile.
				//Pushing back into the vector causes only the entries from the first gene to be saved, while the second, lost.
				//Try to call a function that builds the common entries here. Call it Build_match_table(). 
				//To be useful, separate output methods are required to retreive data from this table as well.
				common_entries.push_back(unique_list1[i]);

				common_entries1.push_back(unique_list1[i]);
				common_entries2.push_back(unique_list2[j]);
				//biuld_match_table();
				/**********************
			//	build_match_table (unique_list1, unique_list2){
					match_seq_table[i].push_back(unique_list1[i]);
					match_seq_table[i].push_back(unique_list2[j]);
				/*********************/		

			}//if
		}//for j
	}//the O(M*N) way; but since the lists were alreaday sorted, not that bad.
	
	/******************
		for (int i = 0; i < match_seq_table.size(); i++){
					for (int j = 0; j < match_seq_table[i].size(); j++){
						cout<<match_seq_table[i][j];
					}
					cout<<'\n';
		}
	/******************/

	/**/
	for (int i = 0; i<common_entries1.size(); i++){
		cout<<i<<'\t'<<common_entries1[i]<<endl;
	}

	for (int i = 0; i<common_entries2.size(); i++){
		cout<<i<<'\t'<<common_entries2[i]<<endl;
	}

	/**/

	/***
	vector<string>::iterator it;
	sort(list1.begin(),list1.end());
	sort(list2.begin(), list2.end());
	it = set_intersection(list1.begin(), list1.end(), list2.begin(),list2.end(),common_entries.begin());
	common_entries.resize(it-common_entries.begin());
	for (it=common_entries.begin(); it!=common_entries.end(); ++it)
    cout << ' ' << *it;
	cout << '\n';
	***/
	
	/**
	for (vector<string>::size_type i = 0; i < common_entries.size(); i++){
		cout<<i+1<< '\t'<<common_entries[i]<<endl;
	}
	/**/
	return common_entries;
}

vector <string> remove_redundant (vector <string> input_vector){
	//This function uses "sort" and "erase" combination to remove redundant entries in a vector.
	vector <string> output_vector;
	sort(input_vector.begin(), input_vector.end());
	input_vector.erase(unique(input_vector.begin(), input_vector.end()), input_vector.end());
	output_vector = input_vector;
	return output_vector;
}

int compare_entries (string sequence1, string sequence2){
	int result = 9; //initialize to a nonsense value
	//This function compares 2 strings according to a given criterion. 
	//The simplest criterion is that two strings are the same.
	//This function returns the value of "true" if the criterion is satisfied.
	
	
	/*************************************
	result = sequence1.compare(sequence2);
	/*************************************/

	//The following should implement the regular expression matching or pattern matching between 2 strings.
	//If both strings match a common pattern or a regular expression, then the return result of 0;
	//NOTE!!! Since a profile matching is used, the method assumes that the input string is 21 nt, the maximum length of shRNA

	//Define 2 regions in the target sites that must match by "pattern_start1 and _end1" positions 
	//and "pattern_start2 and _end2" positions. 

	/***************/
	int pattern_start1_pos = 13; 
	int pattern_1_len = 7; //perfect match for 7 nt seed
	int pattern_start2_pos = 5; //This matching postion leaves 3 nt of mismatch; then 4 nt mismatch will also be tried by +1
	int pattern_2_len = 4; //So and the end point will be extended by 1, after checking the current position.
	
	
	string seq1_part1, seq1_part2, seq1_part2_ext, seq2_part1, seq2_part2, seq2_part2_ext;
	seq1_part1 = sequence1.substr(pattern_start1_pos, pattern_1_len);
	seq1_part2 = sequence1.substr(pattern_start2_pos, pattern_2_len);
	seq1_part2_ext = sequence1.substr((pattern_start2_pos +1), (pattern_2_len));

	seq2_part1 = sequence2.substr(pattern_start1_pos, pattern_1_len);
	seq2_part2 = sequence2.substr(pattern_start2_pos, pattern_2_len);
	seq2_part2_ext = sequence2.substr((pattern_start2_pos + 1), (pattern_2_len));

	if ((seq1_part1.compare(seq2_part1)==0)&&(seq1_part2.compare(seq2_part2)==0)){
		result = 0;
	}


	else if ((seq1_part1.compare(seq2_part1)==0)&&(seq1_part2_ext.compare(seq2_part2)==0)){
		result = 0;
	}

	else if ((seq1_part1.compare(seq2_part1)==0)&&(seq1_part2.compare(seq2_part2_ext)==0)){
		result = 0;
	}

	else if ((seq1_part1.compare(seq2_part1)==0)&&(seq1_part2_ext.compare(seq2_part2_ext)==0)){
		result = 0;
	}
/**********
//****************/
	return result;
}

//build the 2-D array of all matching subsequences

vector <string> make_site_list(string file_name, int window_size){

	string gene_seq = get_search_area(file_name);
	//store the first gene sequence in a continuous string
	//now make a list of the seed binding sites for gene 1
	
	vector<string> bd_list;

	for (int i = 0; i<=gene_seq.length()-window_size;i++){
		string seedbd = gene_seq.substr(i,window_size);
	//	cout<<seedbd<<endl;
		bd_list.push_back(seedbd);
	}

	return bd_list;
}
Mode2_parameters ask_user_parameters(){
	//the batch input file for this functions is fixed for now. Should implement an interface for it later

	int seed_length = get_seed_size();
	int site_size = get_site_size();

	//string input_batch_file = 
	//	"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchIn/mode2_in_file.txt";
	//"C:/Documents and Settings/yifei.GRAD-9F0B36CEBF/My Documents/Lab/Compute/SeedSearchOut/Sitelist.txt";

	string gene1_file = "";
	string gene2_file = "";
	string mode2_outfile = "";

	//gene1_file = get_gene1_file();
	//gene2_file = get_gene2_file();

	vector<string> gene_file_list = get_gene_files(input_batch_file);
	gene1_file = gene_file_list[0];
	gene2_file = gene_file_list[1];
	//for (vector<int>::size_type i = 0; i < gene_file_list.size(); i++){
		//	myfile << i+1 << '\t' << index_list[i] << '\t' << site_list [i] << endl;
		//}
//	cout<<"First gene file: "<< gene1_file<<endl;
//	cout<<"Second gene file: "<<gene2_file<<endl;
	//mode2_outfile = "mode2_out.txt";
	//mode2_outfile = get_commonseed_outfile();
	Mode2_parameters parameters = {seed_length, site_size, gene1_file, gene2_file}; 

	return parameters;
}
int get_seed_size(){
	cout<<"Please enter the size of the common seed binding site that you wish to find in the two sequenes:"<<endl;
	cout<<"For example: 7"<<endl;
	//convert cin to an integer;
	string input = "";
	int seed_size=0;
	while (true) {
	   getline(cin, input);
	   // This code converts from string to number safely.
	stringstream myStream(input);
	if (myStream >> seed_size)
		 break;
	cout << "Invalid number, please try again" << endl;
	}
	//cout << "You entered: " << myNumber << endl << endl;
	return seed_size;
}
int get_site_size(){
	cout<<"Please enter the size of the complete shRNA we wish to design:"<<endl;
	cout<<"For example: 21"<<endl;
	//convert cin to an integer;
	string input = "";
	int site_size=0;
	while (true) {
	   getline(cin, input);
	   // This code converts from string to number safely.
	stringstream myStream(input);
	if (myStream >> site_size)
		 break;
	cout << "Invalid number, please try again" << endl;
	}
	//cout << "You entered: " << myNumber << endl << endl;
	return site_size;
}
vector<string> get_gene_files(string file_name){
//asks the user to specify the name and location of the FASTA file of the first gene (cDNA) sequence
	//string filename;
	int i=0; //keep track of number of lines in the input file
	string word;
	vector<string> file_list;

	ifstream infile (file_name);
	if (infile.is_open())
	{
		while (infile.good())
		{
			getline (infile, word);
			//cout << word << endl;
			if (word.length() > 0){
	//			i++; //counts the number of file names in the input
				file_list.push_back(word);
	//			cout<<"input file "<<i<<": "<<word<<endl;
			}//if word length > 0
		}//while
	infile.close();
	}//if
	else cout << "Unable to open gene file"<<endl; 
//	return stored_seq;
	return file_list;
}
string get_commonseed_outfile(){
//asks the user to specify the name and location of the output file of mode 2 of the program
	string out_file = "";
	return out_file;

}
string get_search_area(string file_name){
	string seq_name;
	string temp_seq;// a temporary variable that holds the current line read, will be appended to when next line is read to construct a new sequence.
	vector<string> name_list; //read all sequence names from the file into this vector
	vector<string> all_seq; // read all sequences from the file into this vector
	//int i=0; //keep track of number of lines in the input file
	int name_len;
	string word, stored_seq; 
	ifstream infile (file_name);
	if (infile.is_open())
	{
		int seq_count = 0; //trace the current sequence being analyzed
		while ( infile.good())
		{
		getline (infile, word);
		//cout << word << endl;
		if (word.length() > 0){
		//i++; 
		
		//cout << ' '<< i;
			if (word[0] == '>') {
				seq_count++;
				name_len = word.length()-1;
				seq_name = word.substr(1,name_len);
				/***
				if (seq_count == 1){//if this is the first sequence in the file
						//add this name to the vector of sequence names
						name_list.push_back(seq_name);
					}
					else { //this is not the first sequence in the file, meaning that previous sequence has just been finished.
						//stor the sequence into a vector
						temp_seq.append(word);
					}
					***/
				}//if first char is '>'
			else {	//this is not a line for the sequence name, this is a line of the actual sequence
				transform(word.begin(), word.end(), word.begin(), toupper);
				stored_seq.append(word); //build a continuous sequence of the FASTA file sequence
				}
			}//if word length > 0
		}//while
	infile.close();
	}//if
	else cout << "Unable to open input file"; 
//	cout<<seq_name<<endl;
//	cout<<stored_seq<<endl;
	return stored_seq;
}

string get_subseq (){
	//prompt the user to enter either the seed sequenc in shRNA, 
	//or the seed binding site in the target site.
	
	string answer, upper_answer;
	string subseq="";
	int subseq_len = 0;
	
	cout << "Are you entering the seed sequence in your shRNA? (Y/N)"<< endl;
	getline(cin, answer);

	//convert user input answer to upper case
	transform(answer.begin(),answer.end(), answer.begin(), toupper); 
	/***
	locale loc;
	for (size_t i =0; i <answer.length();++i){
	upper_answer.at(i)= toupper(answer[i],loc);
	}
	***/
	
	if (answer.compare("YES")==0 || answer.compare("Y")==0){
		cout << "Please enter the seed sequence in your shRNA: "<< endl;
		getline(cin,subseq);	
		subseq_len = subseq.length();
		transform(subseq.begin(), subseq.end(), subseq.begin(), toupper); 
	//convert all input characters to uppercase regardless
		subseq = reverse_complement(subseq); 
	//converts the shRNA seed to reverse complement to search in mRNA
	}
	else if (answer.compare("NO")==0 ||answer.compare("N")==0) {
		cout << "Please enter the seed binding site sequence in the target sequence," <<endl <<"which is the reverse complement of the shRNA seed: " <<endl;
		getline(cin,subseq);	
		subseq_len = subseq.length();
		transform(subseq.begin(), subseq.end(), subseq.begin(), toupper); 
	}
	else {
		cout << "You entered an invalid choice." << endl <<"Exiting program... "<<endl;
		//system("pause");
		//exit;
		subseq = "???";
	}
	cout << "target subsequence is: " << subseq << endl;
	return subseq;
}

vector<int> subseq_search(string sub_seq, string long_seq){
	vector <int> site_list;
	int Num_sites = 0;
	size_t found;

	found = long_seq.find(sub_seq);
	if (found != string::npos) {
		do {
		Num_sites++;
		site_list.push_back(int(found)); 
		//save the found starting position of the substring into a list

		found = long_seq.find (sub_seq, found+1);
		} while (found != string::npos);
		//while
	//	cout << "Seed " << sub_seq<<" There are in total " << Num_sites << " of sites that match the seed." << endl;  
	} 
	else cout<< "No seed found." << endl;
	return site_list;
}//subseq_search

vector<string> get_shRNA_sites(vector<int> index_list, int site_length, int substr_len, string seq) //this is the total sequence of the target  
	{
	vector<string> list_shRNA_sites;
	//int site_len = site_length;
	int non_seed_site_len = site_length - substr_len; 
		// the seed is at the 3' end of the target site, calculate the starting index by this offset

	for (vector<int>::size_type i = 0; i < index_list.size(); i++){
	// the start location must not be negative.
		if ((index_list[i] - non_seed_site_len + 1) >= 0){
			list_shRNA_sites.push_back(seq.substr(index_list[i] - non_seed_site_len + 1, site_length));
			//from the target site index in the index_list, if we move backward by the number of positions
			//occupied by the non-seed sequences, then we can find the starting position of the target site
			//of the putative shRNA. From the start site, we retrieve a substring of size of site_length,
			//which is the size of the shRNA. "+1" because we need one nucleotide beyond the start of seed
			//to be the starting nucleotide of the siRNA (preferrably an A/U).
		}
		else {
			list_shRNA_sites.push_back("Beyond RNA sequence");
		}
	}
	return list_shRNA_sites;
}

void save_sitelist2file(vector<int> index_list, vector<string> site_list, string out_file){
	ofstream myfile;
	myfile.open (out_file);
	myfile << "List of the sites " << endl;
	for (vector<int>::size_type i = 0; i < index_list.size(); i++){
			myfile << i+1 << '\t' << index_list[i] << '\t' << site_list [i] << endl;
		}
	//myfile << "Writing this to a file.\n";
	myfile.close();
}

void save_mode2out (string out_file, vector<seed_info> all_seeds){
	ofstream myfile;
	myfile.open (out_file);
	//myfile << "List of the sites " << endl;
	//for (vector<int>::size_type i = 0; i < index_list.size(); i++){
		//	myfile << i+1 << '\t' << index_list[i] << '\t' << site_list [i] << endl;
	//	}
//	myfile << "Mode2out to a file.\n";

	myfile<<"site"<< '\t'
		<<"seed_id"<< '\t'
		<<"mult"<< '\t'
		<< "Gene_seq_id"<< '\t'
		<<"seed_seq"<< '\t'
		<<"pos_in_gene" <<'\t' 
		<<"shRNA_site_seq"
		<< endl;

	for (vector<seed_info>::size_type i = 0; i<all_seeds.size();i++){ 
		myfile << i+1 << '\t' 
			<< all_seeds[i].seed_id_num << '\t'
			<< all_seeds[i].seed_multiplicity << '\t'
			<< all_seeds[i].gene_id << '\t'
			<< all_seeds[i].seed_seq << '\t'
			<< all_seeds[i].seed_pos << '\t'
			<< all_seeds[i].site_seq << '\t'
			<< endl;
	}


	for (int i = 0; i<common_entries1.size(); i++){
		myfile<<i<<'\t'<<common_entries[i]<<endl;
	}
	for (int i = 0; i<common_entries2.size(); i++){
		myfile<<i<<'\t'<<common_entries2[i]<<endl;
	}


	myfile.close();
}
string reverse_complement(string query_DNA){
    int siRNA_length = query_DNA.length();
    string complementDNA = ""; 
    string revCompDNA = "";
    	
	//System.out.println(siRNA_length);
    complementDNA = get_complement(query_DNA);
    revCompDNA = get_reverse(complementDNA);
	cout<<"The RevComp of your input is: "<< endl << revCompDNA<<endl; 
    return revCompDNA; 
    }   

string get_complement (string DNAseq){
   		string complementDNA = "";
   		int seq_length = DNAseq.length();
   		for (int i = 0; i < seq_length; i++){	
   			char current = DNAseq.at(i);
   			switch (current){
   				case 'A':
   					complementDNA = complementDNA.append("T");
   				break;
   				case 'a': 
   					complementDNA = complementDNA.append("t");
   				break;
   				case 'T': 
   					complementDNA = complementDNA.append("A"); 
   				break;
   				case 't': 
   					complementDNA = complementDNA.append("a");
   				break;
   				case 'G': 
   					complementDNA = complementDNA.append("C");
   				break;
   				case 'g': 
   					complementDNA = complementDNA.append("c");
   				break;
   				case 'C': 
   					complementDNA = complementDNA.append("G");
   				break;
   				case 'c': 
   					complementDNA = complementDNA.append("g");
   				break;					
   			
   			} //switch		
   		} //for
   	//	System.out.println(complementDNA);
   		return complementDNA;
    }// get_complement

string get_reverse (string DNAseq){// This method takes a string of DNA sequences as input and outputs the reverse sequence.
    	int seq_len = DNAseq.length();	
    	//char next_base;
		string reverseDNA = "";
    	
    	for (int i=seq_len-1;i>=0;i--){
    		reverseDNA.insert(seq_len-i-1, 1, DNAseq.at(i));		
    	}	
    	//reverseDNA = new String(reversed); //convert an array of chars to a string
    //	System.out.println(reverseDNA);	
    	
    	return reverseDNA;
    }