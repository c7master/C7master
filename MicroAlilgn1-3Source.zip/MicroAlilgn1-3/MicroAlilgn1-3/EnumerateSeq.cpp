using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

#include "EnumerateSeq.h";

vector<string> EnumerateSeq::enumerate(int seq_len){
	//given a sequence length, populate a list with all possible sequences of the given length.

	vector<string> baselist;
	//below initialized the base list;
	baselist.push_back("A");
	baselist.push_back("C");
	baselist.push_back("G");
	baselist.push_back("T");

	vector<string> result;
	vector<string> cons;

	if (seq_len==1){//base case	
		for (int j = 0; j < baselist.size();j++){
			cons.push_back(baselist[j]);
	} 
	//result = cons;
		return cons;
	}//this is the base case
	else {//recursive call
			for(int j = 0; j <baselist.size();j++){
				vector<string> temp_table = enumerate(seq_len -1 );//recursion to construct seq of len-1
				for (int k =0; k< temp_table.size();k++){//loop through all 4 bases, each time adding  1 base, save a new entry in the list
				cons.push_back(temp_table[k].append(baselist[j]));
				}
				//recursion that appends 4 possible bases to a previous oligo
			}//for j, each base in the base list
//		}//for i, each possible len for the constructed oligo
		result = cons;
		
	}//else
	return result;
}//enumerate recursion

vector<string> EnumerateSeq::enumerateWC(string input){
	//for a givn sequence, produce a list of all possible wobble complementary sequences
	//use recursion for this function. Base case: n = 1, make a list of wobble base pairs for that one nt
	// recursion: for every nt in the sequence, a temporary complementary list is constructed by adding the possible wobble complement nts
	// to each entry of the existing list of wobble complement sequence to the remaining substring.
	vector<string> result;
	if (input.size() == 1){//base case
		result = lookupWC(input);
			return result;
	}//if base-case
	else {//the recursion code here
		vector<string> list1 = lookupWC(input.substr(0,1)); //list 1 holds current position 1 nt wobble base pair nt, 
		vector <string> list2; 	//list2 holds the result of recursions for the remaining substring.

		list2 = enumerateWC(input.substr(1)); //recursive call for the remainder of the sequence, starting at position 1 to the end

		for (int j = 0; j < list2.size(); j++){//The recursive call MUST be the OUTER loop!!!! (STILL not clear WHY!)
			for (int i = 0; i < list1.size(); i++){//The one starting base MUST be the inner loop!!!! Otherwise, the recursion does not work!!!
			string current_base = list1[i];
			result.push_back(current_base.append(list2[j]));
			}//for every entry in the current 1 nt at start position
		}//for every entry in the constructed list for the remaining sequence
		return result;
	}//else: end of recursion
	
}//method end.

vector<string> EnumerateSeq::lookupWC (string nucleotide){
	vector<string> templist1;
	if (nucleotide == "A"){//if A then T
			templist1.push_back("T");
			}
	else if (nucleotide == "C"){//if C then G
			templist1.push_back("G");
			}
	else if (nucleotide == "G"){//if G then C or U
			templist1.push_back("C");
			templist1.push_back("T");
			}
	else if (nucleotide == "T"){//of U then A or G
			templist1.push_back("A");
			templist1.push_back("G");
			}
	else{
		 cout<<"The sequence contains non-recognized characters, please double check you input sequence."<<endl;
			}//not a nucleotide.
			return templist1;
}