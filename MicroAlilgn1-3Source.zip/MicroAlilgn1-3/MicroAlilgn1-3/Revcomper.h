using namespace std;

#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

#ifndef REVERSER_H
#define REVERSER_H
#include "Reverser.h"
#endif

#ifndef COMPLEMENTER_H
#define COMPLEMENTER_H
#include "Complementer.h"
#endif

class Revcomper {
public:	
	string reverse_complement(string query_DNA);
};