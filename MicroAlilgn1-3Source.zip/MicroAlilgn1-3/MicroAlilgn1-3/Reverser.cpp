using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>
#include "Reverser.h"


string Reverser::get_reverse (string DNA_reverse){// This method takes a string of DNA sequences as input and outputs the reverse sequence.
    	int seq_len = DNA_reverse.length();	
    	//char next_base;
		string reverseDNA = "";
    	
    	for (int i=seq_len-1;i>=0;i--){
    		reverseDNA.insert(seq_len-i-1, 1, DNA_reverse.at(i));		
    	}	
    	//reverseDNA = new String(reversed); //convert an array of chars to a string
    //	System.out.println(reverseDNA);	
    	
    	return reverseDNA;
    }