using namespace std;
#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>
#include "SubseqLister.h"
//#include "Fasta_parser.h"

vector <slidingWin_seqlist> SubseqLister:: make_site_list(vector<fasta_sequence> seqlist){
	int window_size = 27;
	int sequence_numbers = seqlist.size();
	vector <slidingWin_seqlist> bd_list;
	//string temp_subseq; 

	for (int i = 0; i<seqlist.size();i++){
		bd_list.push_back(slidingWin_seqlist ()); //add an empty row for each sequence in the All_sequence list
	}

	cout<<"store tiling sequences in a list..."<<endl;
	for (int i = 0; i<seqlist.size();i++){
		bd_list[i].seq_name = (seqlist[i].sequence_name);//store the sequence name in this new row
		cout<<bd_list[i].seq_name<<endl;
		for (int j = 0; j <= seqlist[i].sequence.size()-window_size;j++){
			string temp_subseq = seqlist[i].sequence.substr(j,window_size);
			bd_list[i].SlidingSeqList.push_back(temp_subseq);
		}
	}
	return bd_list;
}