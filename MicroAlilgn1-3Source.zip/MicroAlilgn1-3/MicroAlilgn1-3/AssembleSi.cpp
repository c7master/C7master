#include "AssembleSi.h"
//This method takes different parts of the siRNA found by the program (seed, bulge, and tail) and put them together.
vector<si_target_info> AssembleSi::assembleSiRNA (vector<seed_bulge_tail> seedtargetinfo){

	vector<si_target_info> siDesigns; //define output 

	for (vector<seed_bulge_tail>::size_type i = 0; i < seedtargetinfo.size(); i++){

		string current_seed= seedtargetinfo[i].seed_seq;	

		for (vector<seed_bulge_tail>::size_type j = 0; j< seedtargetinfo[i].bulgetails.size();j++){

			si_target_info current_siDesign; //declare temporary entry;
		
			string curr_qery_bulge = seedtargetinfo[i].bulgetails[j].bulge;
			string curr_query_nmer = seedtargetinfo[i].bulgetails[j].nmer;	
			string curr_query_tail = seedtargetinfo[i].bulgetails[j].tail;

			current_siDesign.siSeq = cons_siRNA(current_seed, curr_qery_bulge, curr_query_nmer, curr_query_tail);

			vector<target_info> info_targets;//declare the next level data struct
			target_info currTargetInfo; //tempoaray entry

			for (int k =0; k < seedtargetinfo[i].bulgetails[j].targets.size();k++){

				currTargetInfo.gene_name = seedtargetinfo[i].bulgetails[j].gene_names[k];
				currTargetInfo.pos = seedtargetinfo[i].bulgetails[j].target_positions[k];
				currTargetInfo.target_seq = seedtargetinfo[i].bulgetails[j].targets[k];
				currTargetInfo.score = seedtargetinfo[i].bulgetails[j].trimatch_scores[k];

				info_targets.push_back(currTargetInfo);	

			}//for k, all targets in all genes

			current_siDesign.targets = info_targets; //pass the vector of struct to "targets" table

			siDesigns.push_back(current_siDesign);//save to the output table, of size i X j.
		}//for j, each n-mer
	
	}//for i, each seed
	
	return siDesigns;
}//end assemble siRNA table

string AssembleSi::cons_siRNA(string inputseed, string inputbulge, string inputcenter, string inputtail){
	//At the present stage, seed sequence is in mRNA sense; n-mer is in complementary to mRNA; bulge/tail is in mRNA-sense
	//To design siRNA, need to rev-comp the seed, the bulge and the tail, then reverse the n-mer, in order to obtain 5'-3' siRNA
	//Assemble in the following order: T + seed + bulge + n-mer + tail.

	string siRNA_seq;

	Revcomper rc;
	Reverser rv;

	string outputseed, outputbulge, outputcenter, outputtail;
	outputseed = rc.reverse_complement(inputseed);
	outputbulge = rc.reverse_complement(inputbulge);
	outputtail = rc.reverse_complement(inputtail);
	outputcenter = rv.get_reverse(inputcenter);

	siRNA_seq = "T" + outputseed + outputbulge + outputcenter + outputtail;
	//cout<<siRNA_seq;
	return siRNA_seq;
}//cons_siRNA
