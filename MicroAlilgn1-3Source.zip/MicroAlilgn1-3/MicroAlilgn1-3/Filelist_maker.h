
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>


#ifndef FASTA_PARSER_H
#define FASTA_PARSER_H
#include "Fasta_parser.h"
#endif


class Filelist_maker{
public:
	vector <string> generate_filelist(string inputFile);
	vector<fasta_sequence> multiFile_seqlist(string file_name);
};