using namespace std;

#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>

#ifndef ALIGNER_H
#define ALIGNER_H
#include "Aligner.h"
#endif

#ifndef ALIGNASSEMBLED_H
#define ALIGNASSEMBLED_H
#include "AlignAssembled.h"
#endif


struct caltarget {//holds calculated informations about the siRNA targeting
//	vector<siRNA_target_align> sitarinfo; //the structs have redundant siRNA sequence information
	int siRNA_ID; //The unique index number for each siRNA
	string siRNA_seq;
	double total_above_miScore; //total of miScores that are above the threshold
	double average_above_miScore; //average of miScore that are above the threshold  
	//double total_above_offtar_miScore; //total of miScores that are above the threshold from off-targets;
	int target_counts; //number of targets that are hit above the threshold score
//	double total_offtarget_avidity; //concentration-corrected total off-targeting score
};


struct MyPredicate{//straight from stack-overflow for sorting vector of sturct
	bool operator() (const caltarget& siRNA1, const caltarget& siRNA2){ //user-defined comparsion function for sortiing the vector<caltarget>
		
			return(siRNA1.total_above_miScore > siRNA2.total_above_miScore);
	}//bool

};

class ScoreSelector{

public:

	vector<caltarget> select_siRNAs(vector<siRNA_target_align>); //master method that calls all others: clauclate total, calculate average, sort vector of struct

	vector <caltarget> calScores (vector<siRNA_target_align> align_results);// calculate all the scores parameters for the the aligned results. group identical siRNAs together.

	double total_aboveScore (siRNA_target_align sitar_info); //calculates the total score
	double get_average_aboveScore(double total, int count); //calculate the average score for each siRNA
	vector <caltarget> skimtop(vector<caltarget> all_calculated); //takes all the siRNAs with calculated scores and return the ones with top scores. 
	bool sortByTotalScores(const caltarget& siRNA1, const caltarget& siRNA2); //user-defined comparsion function for sortiing the vector<caltarget>

};