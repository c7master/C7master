



/*********SeqPro's Scorer****************/

#include "Scorer.h"	


double Scorer::get_score(int seed_end, int query_pos, int subject_pos, string symbol, string strand_lable){
	//declare output
	int curr_score;

	/********
	//define scores by regions, match symbol type, and strand

	Strand labels to specify which strand we are looking at in case of a space (" ") in alignment
	query = "q"
	subject - "s"
	mismatch = "m"

	*********/

	//store scores in a 5X4 integer array.

	/*****
			seed	bulge	center1	center2		tail
	wc		3		5		12		9			1
	wb		-4		2		4		3			1
	mm		-4		-5		-12		-9			0
	q-gap	-7		-5		-12		-9			0
	s-gap	-7		-3      -6		-4			0
	****/
/****
	int score_matrix[5][5] ={//seed  A     B   C   D
							   {6,   2,   3,  2,  2},  //wc
							   {-4,  1,   1,  1,  1},  //wob
							   {0,  -2,  -3,  -3, 0},  //mm
							   {-6, -4,  -4,  -4, 0},  //q-gap
							   {-6, -2,  -2,  -2, 0},  //s-gap
							};
****/

	/*******
		int score_matrix[5][5] ={//seed  A     B   C   D
							   {3,   5,   12,  9,  1},  //wc
							   {-4,  2,   4,  3,  1},  //wob
							   {-4,  -5,  -12,  -9, 0},  //mm
							   {-15, -5,  -12,  -9, 0},  //q-gap
							   {-15, -3,  -6,  -4, 0},  //s-gap
							};
		/****
		//Additive model of scoring function, SeqPro matrix
		int score_matrix[5][5] ={//seed  A     B   C   D
								{6,	6,    8,   8, 3},  //wc
							   {-6,     3,    2,   4,  1},  //wob
							   {-6,     0,    0,   0,  0},  //mm
							   {0, 0,  0,  0, 0},  //q-gap
							   {0, 0,  0,  0, 0},  //s-gap
							};
		*****/
	/****
	int score_matrix[5][5] ={//s A  B  C  D
	/***The calibrated version in the correlation plot, posted online***
	{8, 2, 5, 4, 0},  //wc	
    {-12, 1, 3, 2, 0},  //wob	
    {-12, -4, -5, -5, 1},  //mm	
    {-12, -4, -5, -4, 1},  //q-gap	
    {-12, -2, -3, -4, 1},  //s-gap	
	};
	****/
	/*****The original MA1-1 score matrix used in paper*****************/

	int score_matrix[5][5] ={//s A  B  C  D	
	{8, 2, 5, 4, 0},  //wc
    {-30, 1, 3, 2, 0},  //wob	
    {-30, -4, -5, -5, 1},  //mm	
    {-30, -4, -5, -4, 1},  //q-gap	
    {-30, -2, -3, -4, 1},  //s-gap	
	};	


	/**********************/


	int bulge_size = 3; //A-region

	int body1_size = 3; //B-region

	int body2_size = 3; //C-region

	int tail_size = 4; //D-region
	

	//calculate bulge, center body, and tail positions.

	seed_end = seed_end +1;
	int seed_start =  seed_end + 6; //here for position calculation, last nt is included in the seed. In scoring, last nt in target not counted as part of seed.
	
	int bulge_start = seed_end -1;
	
	int body1_start = bulge_start -bulge_size;

	int body2_start = body1_start -body1_size;

	int tail_start = body2_start - body2_size;

	int bulge_end = bulge_start - bulge_size + 1;

	int body1_end = body1_start - body1_size + 1;

	int body2_end = body2_start - body2_size + 1;

	int tail_end = 0;
	
	/*****************************************
	cout<<"seed starts at :"<<seed_start<<endl;
	cout<<"seed ends at :"<<seed_end<<endl;

	cout<<"bulge starts at :"<<bulge_start<<endl;
	cout<<"bulge ends at :"<<bulge_end<<endl;

	cout<<"center body starts at :"<<body_start<<endl;
	cout<<"center body ends at :"<<body_end<<endl;

	cout<<"tail starts at :"<<tail_start<<endl;
	cout<<"tail ends at :"<<tail_end<<endl;
	****************************************/




	/****
	In order to implement regional inter-dependence, regional score need to be kept.
	In order to quantitate the degree of unpairing, the number of spaces will be recorded.
	***/

//	cout<<"qery_pos = "<<query_pos<<'\t';

	if (query_pos >= seed_end && query_pos <= seed_start) {//score the seed region
		
		if (symbol.compare ("|") == 0 ){//wc
			
			curr_score = score_matrix[0][0];
		}
		else if (symbol.compare ("*") == 0){//wobble
			curr_score = score_matrix[1][0];
		}
		else if (symbol.compare (" ") == 0){//mismatch or gap

			if (strand_lable.compare("m")==0 ){
				curr_score = score_matrix[2][0];
			}
			if (strand_lable.compare("q")==0 ){
				curr_score = score_matrix[3][0];
			}
			if (strand_lable.compare("s")==0 ){
				curr_score = score_matrix[4][0];
			}		
		}//space in symbol
		
	}//seed region

	else if (query_pos >= bulge_end && query_pos <= bulge_start) {//score the A-region
		
		if (symbol.compare ("|") == 0 ){//wc
			
			curr_score = score_matrix[0][1];
		}
		else if (symbol.compare ("*") == 0){
			curr_score = score_matrix[1][1];
		}
		else if (symbol.compare (" ") == 0){

			if (strand_lable.compare("m")==0 ){
				curr_score = score_matrix[2][1];
			}
			if (strand_lable.compare("q")==0 ){
				curr_score = score_matrix[3][1];
			}
			if (strand_lable.compare("s")==0 ){
				curr_score = score_matrix[4][1];
			}	

		}//space in symbol

	}//bulge

	else if (query_pos >= body1_end && query_pos <= body1_start) {//score the B-region
		
		if (symbol.compare ("|") == 0 ){//wc
			
			curr_score = score_matrix[0][2];
		}
		else if (symbol.compare ("*") == 0){
			curr_score = score_matrix[1][2];
		}
		else if (symbol.compare (" ") == 0){

			if (strand_lable.compare("m")==0 ){
				curr_score = score_matrix[2][2];
			}
			if (strand_lable.compare("q")==0 ){
				curr_score = score_matrix[3][2];
			}
			if (strand_lable.compare("s")==0 ){
				curr_score = score_matrix[4][2];
			}		

		}//space in symbol

	}//center-body

		else if (query_pos >= body2_end && query_pos <= body2_start) {//score the C-region
		
		if (symbol.compare ("|") == 0 ){//wc
			
			curr_score = score_matrix[0][3];
		}
		else if (symbol.compare ("*") == 0){
			curr_score = score_matrix[1][3];
		}
		else if (symbol.compare (" ") == 0){

			if (strand_lable.compare("m")==0 ){
				curr_score = score_matrix[2][3];
			}
			if (strand_lable.compare("q")==0 ){
				curr_score = score_matrix[3][3];
			}
			if (strand_lable.compare("s")==0 ){
				curr_score = score_matrix[4][3];
			}	
		}//space in symbol

	}//center-body

	else if (query_pos >= tail_end && query_pos <= tail_start) {//score the tail region
		
		if (symbol.compare ("|") == 0 ){//wc
			
			curr_score = score_matrix[0][4];
		}
		else if (symbol.compare ("*") == 0){
			curr_score = score_matrix[1][4];
		}
		else if (symbol.compare (" ") == 0){

			if (strand_lable.compare("m")==0 ){
				curr_score = score_matrix[2][4];
			}
			if (strand_lable.compare("q")==0 ){
				curr_score = score_matrix[3][4];
			}
			if (strand_lable.compare("s")==0 ){
				curr_score = score_matrix[4][4];
			}		

		}//space in symbol
	}//tail
	else curr_score = 0; // outof bounds or the first nt in the seed doesn't count.

	//cout<<"Current score is: "<<curr_score<<endl;
	return curr_score;

}

double Scorer::score_alignment(string query, string subject, string align_symbols, string entire_subject){
	//query, subject, and alignment symbols are directly from the alignmet_config struct.
	//This means that query is on top, siRNA sequence in 3'->5' direction, 21 nt; symbol string in the middle, 
	//and the target is at the bottom, in 5'->3' direction, anywhere between 21 to 27 nt. 
	//target nucleotide positions for center, bulge and tail definition need to be calculated according to the input length.

	//declare output
	int total_score = 0;


	//parpare variables for calculation

	//keep track of nucleotide pos counts for query and subject, used to determine which region we are looking at.
	int query_nt_ct =0; 
	int subject_nt_ct=0; 
	int seed_length = 8;

	/*****************************/	
//	int seed_end = entire_subject.length()-seed_length; //entire_subject contains no symbol of alignment
	//int seed_end = query.length()-seed_length; //entire_subject contains no symbol of alignment
	int seed_end = 13;
	int bulge_size = 3; //A-region

	int body1_size = 3; //B-region

	int body2_size = 3; //C-region

	int tail_size = 4; //D-region
	

	//calculate bulge, center body, and tail positions.
	

	int seed_start = seed_end + 7;//start at the last nt in the target, index 20
	
	int bulge_start = seed_end -1;
	
	int body1_start = bulge_start -bulge_size;

	int body2_start = body1_start -body1_size;

	int tail_start = body2_start - body2_size;

	int bulge_end = bulge_start - bulge_size + 1;

	int body1_end = body1_start - body1_size + 1;

	int body2_end = body2_start - body2_size + 1;

	int tail_end = 0;

	/*****************************************
	cout<<"seed start: "<<seed_start<<'\t'
		<<"seed end: "<<seed_end<<'\t'
		<<"A start: "<<bulge_start<<'\t'
		<<"A end: "<<bulge_end<<'\t'
		<<"B end: "<<body1_start<<'\t'
		<<"B end: "<<body1_end<<'\t'
		<<"C start: "<<body2_start<<'\t'
		<<"C end: "<<body2_end<<'\t'
		<<"D start: "<<tail_start<<'\t'
		<<"D end: "<<tail_end<<'\t'<<endl;
	/************************************************/

	/*****************/

	int seedregion_score =0;
	int Aregion_score=0;
	int Bregion_score=0;
	int Cregion_score=0;
	int Dregion_score=0;

	int seedregion_space=0;
	int seedregion_symbol_ct=0;

	int Aregion_space=0;
	int Aregion_symbol_ct=0;

	int Bregion_space=0;
	int Bregion_symbol_ct=0;

	int Cregion_space=0;
	int Cregion_symbol_ct=0;

	int Dregion_space=0;
	int Dregion_symbol_ct=0;

	/*****/
	

	string curr_symbol, curr_query_letter, curr_subject_letter, strand_label;

	int curr_score = 0;
	int symbols_len = align_symbols.length();
	int query_len = query.length();
	int subject_len = subject.length();
	int query_nt_pos = 0;
	for (int i = 0; i< align_symbols.length();i++){
//	for (int i = symbols_len; i>=0;i--){
		

		curr_symbol = align_symbols.substr(i,1);

		curr_query_letter = query.substr(i,1);
		if (curr_query_letter.compare("-")!=0){
			query_nt_pos++;
		} 
		curr_subject_letter = subject.substr(i,1);

		//cout<<"subject nucleotide count: "<<subject_nt_ct<<endl;

		if (curr_symbol.compare("|")==0){//watson-crick pairing

			curr_score = get_score(seed_end, query_nt_pos, subject_nt_ct, curr_symbol, strand_label);//first, get the score; this is region-dependent

			//increment the nt count in the correponding region
			if (subject_nt_ct >= seed_end && subject_nt_ct <= seed_start) {//score the seed region		
				seedregion_symbol_ct++;
				seedregion_score = seedregion_score + curr_score;
			}//seed region
			else if (subject_nt_ct >= bulge_end && subject_nt_ct <= bulge_start) {//score the A-region
				Aregion_symbol_ct++; //count the total number of symbols in this region
				Aregion_score = Aregion_score + curr_score;
			}//bulge
			else if (subject_nt_ct >= body1_end && subject_nt_ct <= body1_start) {//score the B-region
				Bregion_symbol_ct++;
				Bregion_score = Bregion_score + curr_score;
			}//center-body
			else if (subject_nt_ct >= body2_end && subject_nt_ct <= body2_start) {//score the C-region
				Cregion_symbol_ct++;
				Cregion_score = Cregion_score + curr_score;
			}//center-body
			else if (subject_nt_ct >= tail_end && subject_nt_ct <= tail_start) {//score the tail region
				Dregion_symbol_ct++;
				Dregion_score = Dregion_score + curr_score;
			}
			query_nt_ct++;
			subject_nt_ct++;
		//	query_nt_pos++;
		}//wc match

		else if (curr_symbol.compare("*")==0){//wobble pairing
			curr_score = get_score(seed_end, query_nt_pos, subject_nt_ct, curr_symbol, strand_label);

			//increment the nt count in the correponding region
			if (subject_nt_ct >= seed_end && subject_nt_ct <= seed_start) {//score the seed region		
				seedregion_symbol_ct++;
				seedregion_score = seedregion_score + curr_score;
			}//seed region
			else if (subject_nt_ct >= bulge_end && subject_nt_ct <= bulge_start) {//score the A-region
				Aregion_symbol_ct++; //count the total number of symbols in this region
				Aregion_score = Aregion_score + curr_score;
			}//bulge
			else if (subject_nt_ct >= body1_end && subject_nt_ct <= body1_start) {//score the B-region
				Bregion_symbol_ct++;
				Bregion_score = Bregion_score + curr_score;
			}//center-body
			else if (subject_nt_ct >= body2_end && subject_nt_ct <= body2_start) {//score the C-region
				Cregion_symbol_ct++;
				Cregion_score = Cregion_score + curr_score;
			}//center-body
			else if (subject_nt_ct >= tail_end && subject_nt_ct <= tail_start) {//score the tail region
				Dregion_symbol_ct++;
				Dregion_score = Dregion_score + curr_score;
			}

			//get the score for the current nucleotide

			query_nt_ct++;
			subject_nt_ct++;
		//	query_nt_pos++;
		}

		else if (curr_symbol.compare(" ")==0){//gap or mismatch
			//First determine the number of occurrence of space character in each region (A-D),
			//this has to be done before the increment of the subject_nt_ct.

			if (query.substr(i,1).compare("-")==0){//if gap is in query
				strand_label = "q";
				curr_score = get_score(seed_end, query_nt_pos, subject_nt_ct, curr_symbol, strand_label);

				//increment the nt count in the correponding region
				if (subject_nt_ct >= seed_end && subject_nt_ct <= seed_start) {//score the seed region		
					seedregion_symbol_ct++;
					seedregion_space++;
					seedregion_score = seedregion_score + curr_score;
				}//seed region
				else if (subject_nt_ct >= bulge_end && subject_nt_ct <= bulge_start) {//score the A-region
					Aregion_symbol_ct++; //count the total number of symbols in this region
					Aregion_space ++;
					Aregion_score = Aregion_score + curr_score;
				}//bulge

				else if (subject_nt_ct >= body1_end && subject_nt_ct <= body1_start) {//score the B-region
					Bregion_symbol_ct++;
					Bregion_space++;
					Bregion_score = Bregion_score + curr_score;
				}//center-body

				else if (subject_nt_ct >= body2_end && subject_nt_ct <= body2_start) {//score the C-region
					Cregion_symbol_ct++;
					Cregion_space++;
					Cregion_score = Cregion_score + curr_score;
				}//center-body
				else if (subject_nt_ct >= tail_end && subject_nt_ct <= tail_start) {//score the tail region
					Dregion_symbol_ct++;
					Dregion_space++;
					Dregion_score = Dregion_score + curr_score;
				}

				subject_nt_ct++;//gap opened in query, move down 1 nucleotide in subject
			}//gap in query

			else if (subject.substr(i,1).compare("-")==0){//gap in subject
				strand_label = "s";
				curr_score = get_score(seed_end, query_nt_pos, subject_nt_ct, curr_symbol, strand_label);

				//increment the nt count in the correponding region
				if (subject_nt_ct >= seed_end && subject_nt_ct <= seed_start) {//score the seed region		
					seedregion_symbol_ct++;
					seedregion_space++;
					seedregion_score = seedregion_score + curr_score;
				}//seed region
				else if (subject_nt_ct >= bulge_end && subject_nt_ct <= bulge_start) {//score the A-region
					Aregion_symbol_ct++; //count the total number of symbols in this region
					Aregion_space ++;
					Aregion_score = Aregion_score + curr_score;
				}//bulge

				else if (subject_nt_ct >= body1_end && subject_nt_ct <= body1_start) {//score the B-region
					Bregion_symbol_ct++;
					Bregion_space++;
					Bregion_score = Bregion_score + curr_score;
				}//center-body

				else if (subject_nt_ct >= body2_end && subject_nt_ct <= body2_start) {//score the C-region
					Cregion_symbol_ct++;
					Cregion_space++;
					Cregion_score = Cregion_score + curr_score;
				}//center-body
				else if (subject_nt_ct >= tail_end && subject_nt_ct <= tail_start) {//score the tail region
					Dregion_symbol_ct++;
					Dregion_space++;
					Dregion_score = Dregion_score + curr_score;
				}

				query_nt_ct++;
			//	query_nt_pos++;
			}//gap in subject

			else {//else, neither strand contains gap symbol, so it is a mismatch
				strand_label = "m";
				curr_score = get_score(seed_end, query_nt_pos, subject_nt_ct, curr_symbol, strand_label);

				//increment the nt count in the correponding region
				if (subject_nt_ct >= seed_end && subject_nt_ct <= seed_start) {//score the seed region		
					seedregion_symbol_ct++;
					seedregion_space++;
					seedregion_score = seedregion_score + curr_score;
				}//seed region
				else if (subject_nt_ct >= bulge_end && subject_nt_ct <= bulge_start) {//score the A-region
					Aregion_symbol_ct++; //count the total number of symbols in this region
					Aregion_space ++;
					Aregion_score = Aregion_score + curr_score;
				}//bulge

				else if (subject_nt_ct >= body1_end && subject_nt_ct <= body1_start) {//score the B-region
					Bregion_symbol_ct++;
					Bregion_space++;
					Bregion_score = Bregion_score + curr_score;
				}//center-body

				else if (subject_nt_ct >= body2_end && subject_nt_ct <= body2_start) {//score the C-region
					Cregion_symbol_ct++;
					Cregion_space++;
					Cregion_score = Cregion_score + curr_score;
				}//center-body
				else if (subject_nt_ct >= tail_end && subject_nt_ct <= tail_start) {//score the tail region
					Dregion_symbol_ct++;
					Dregion_space++;
					Dregion_score = Dregion_score + curr_score;
				}
				query_nt_ct++;
				subject_nt_ct++;
			//	query_nt_pos++;
			}//mismatch, no gap
				
		}//gap or mismatch

		/****
		cout<<"Current Symbol "<<curr_symbol<<endl;
		cout<<"current subject string nucleotide: "<<subject_nt_ct<<endl;
		cout<<"Current score: "<<curr_score<<endl;

		/*****/
		total_score = total_score + curr_score;
//print out the current score at the beginining of each loop;
//		cout<<curr_score<<'\t'<<curr_symbol<<'\t'<<curr_query_letter<<'\t'<<query_nt_ct<<'\t'<<subject_nt_ct<<'\t'<<query_nt_pos<<endl;
	}//for each symbol in the aligment string

//	cout<<seedregion_score<<'\t'<<Aregion_score<<'\t'<<Bregion_score<<'\t'<<Cregion_score<<'\t'<<Dregion_score<<endl;

		dep_score = calculate_dependent_score(seedregion_score, 
			Aregion_score, Aregion_space, Aregion_symbol_ct, 
			Bregion_score, Bregion_space, Bregion_symbol_ct,
			Cregion_score, Cregion_space, Cregion_symbol_ct,
			Dregion_score, Dregion_space, Dregion_symbol_ct);	

	return dep_score;
		//total_score;

}

double Scorer::calculate_dependent_score(int seed_score, int A_score, int A_unpaired, int A_symbol_ct,
										int B_score,int B_unpaired,int B_symbol_ct,
										int C_score,int C_unpaired,int C_symbol_ct,
										int D_score,int D_unpaired,int D_symbol_ct){
//	declare output
	double output_dep_score;
	//cout<<"A unpair number: :"<<A_unpaired<<'\t'<<"A_symbol_count:"<<A_symbol_ct<<endl;
	
	double A_unpair_ratio = (double)A_unpaired / (double)A_symbol_ct;
	//cout<<"A unpaired ratio: "<<A_unpair_ratio<<endl;
	double A_pair_ratio = 1 - A_unpair_ratio;
//	cout.precision(3);
//	cout<<"A paired ratio: "<<A_pair_ratio<<endl;

	double B_unpair_ratio = (double)B_unpaired / (double)B_symbol_ct;
	double B_pair_ratio = 1 - B_unpair_ratio;
//	cout<<"B paired ratio: "<<B_pair_ratio<<endl;

	double C_unpair_ratio = (double)C_unpaired / (double)C_symbol_ct;
	double C_pair_ratio = 1 - C_unpair_ratio;
//	cout<<"C paired ratio: "<<C_pair_ratio<<endl;

	double D_unpair_ratio = (double)D_unpaired / (double)D_symbol_ct;
	double D_pair_ratio = 1 - D_unpair_ratio;
//	cout<<"D paired ratio: "<<D_pair_ratio<<endl;




		output_dep_score = (double)seed_score + 
			(B_score + //(double)B_unpaired * BPenPerMM //B region score = B-max - penalties
			+ B_pair_ratio*(						//apply B pairing % a coefficient to the rest of duplex
				(C_score + //(double)C_unpaired * CPenPerMM	//C region socre = C-max - penalties
					+ C_pair_ratio * (								//apply C pairing raito a coefficient to the rest of the duplex
						(A_score + //(double)A_unpaired * APenPerMM	//A region score = A-max - penalties
							+ A_pair_ratio * (double)D_score)					//Apply A pairing raito as coefficient to the rest		
					)//C paring ratio on A + D
				)//C + A + D
			)// B pairing ratio on C + A + D
		);//B + C + A + D

	return output_dep_score;
}

