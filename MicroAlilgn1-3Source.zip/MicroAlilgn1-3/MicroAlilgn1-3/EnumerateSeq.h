using namespace std;
#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

class EnumerateSeq{
public:
	vector<string> enumerate(int);
	vector<string> enumerateWC(string);
	vector<string> lookupWC(string);
};