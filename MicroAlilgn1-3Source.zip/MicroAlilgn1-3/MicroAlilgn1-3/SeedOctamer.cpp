/*
This class contains methods that takes the common seed info table and list all viable seeds with
their list of octamers that can wobble pair will all gene targets.

step 1. Make a complete 8-mer table. (this is done inthe main method and passed to SeedOctamer function)
step 2. For each seed in the common seed info table: initialize the temp_list of 8-mers to the 
complete 8-mer table, then go through this list by checking all the sites in the gene one by one. 
Delete current 8-mer from the temp-list if it does not contain any 3-mer of any sites in the given
gene. Use the updated temp-list to search the next gene, till all the sites in the seed are searched.
step 3. For each seed, perform this search and save the temp-list that is associated with the seed
in the final result table called seedOctList. Return this result.
*/

#include "SeedOctamer.h"

/*****************new version of general functions written*******************/



/************************
!!!!!!!!!!!
ListNmers() and produce_8merScores contains length-specific calls, requires manual change. 
Current default is 6, for 6mer covering the BC region.

*************************/

vector <seed_octamer> SeedOctamer::listNmers (vector<common_seed_info> input_table, int N){
	
//	vector<seed_nmer> seed8mer_table;  //this is the output of this function that will be built 

	vector<seed_octamer> seed_Nmer_table;
	seed_octamer current;
	//build the current entry in the result table; 
	//this data structure is used to construct the 8mer table.
	
	//note: "left" refers to the region that is closer to the seed and "right" refers to the farther one.
	//hence, in the site that is 27 nt long, left is between 9 and 14, right is between 11 and 16

	EnumerateSeq ES;
	cout<<"Generating oligomer table..."<<endl;
	vector<string> oligo_table = ES.enumerate(N);
	cout<<"Oligomer table is generated."<<endl;



	for (vector<common_seed_info>::size_type i = 0; i<input_table.size();i++){
		//for each seed in the common_seed_list table, if at least 1 8-mer is found for all gens, 
		//convert to its complement sequences and save this seed with its octmer list
		
		current.seedseq = input_table[i].seed_sequence;
	
		/****convert the seed in mRNA into complement for siRNA 
		Complementer seed_comp;
		current.seedseq = seed_comp.get_complement(input_table[i].seed_sequence);
	//	cout<<"current seed is (3' to 5'direcion, complement of mRNA): "<<current.seedseq<<endl;
		***/

		vector<string> temp_nmer_list =  oligo_table;
		
		//initialize the temp n-mer list to the complete table of n-mers
		//this list will be updated when going through each gene in the stie list.
		
		for (vector<siteinfo>::size_type j = 0; j < input_table[i].site_list.size(); j++){
		//for each gene in the sitelist of the seed

			siteinfo cur_targets_in_gene = input_table[i].site_list[j]; //this contains both the gene name and the site list.
			vector<site_in_gene> sites = cur_targets_in_gene.gene_site_table;
			string current_gene = cur_targets_in_gene.gene_id;

			//construct 6-mer substring of the targe sites of a given gene. The left half.
			int start_pos;
			vector <string> octa_list = make_nmer_sitelist(cur_targets_in_gene, 10, N);//defined the BC region against which the hexamer is designed.
			cout<<"start updating the temp_list for the current gene: "<<current_gene<<endl;
			temp_nmer_list = update_n_mers(temp_nmer_list, octa_list); 
			//builds a new temp list with at least one hit in any site subsequence.

		}//for each gene, construct an octamer list

		current.octamerList = temp_nmer_list;
		
		if (current.octamerList.size() > 0) {
			seed_Nmer_table.push_back(current); //save this entry into the result table if the 8mer list is not empty
			cout<<"Finished "<< i+1 << " of "<< input_table.size()<<" seeds from the common seed table for "<<N<<"-mer search."<<endl;
		}//save only the seeds with non-empty 8mer lists

	}//for each seed

	return seed_Nmer_table;

}//method listOctamers

vector<string> SeedOctamer::make_nmer_sitelist(siteinfo gene_sites, int startpos, int N){

	vector<string> n_mer_inSites;//declare output

	for(vector<site_in_gene>::size_type i = 0; i<gene_sites.gene_site_table.size(); i++){

		string target_site = gene_sites.gene_site_table[i].site_sequence;
		//store the complete target site sequence in a tempoary string

		n_mer_inSites.push_back(target_site.substr(startpos, N));
		//store the substring of the target site according to desired parameters
	
	}//for each target site in the given gene

	return n_mer_inSites;
}//make_nmer_sitelist

vector<string> SeedOctamer::update_n_mers(vector<string> noligos, vector<string> sitesInGene){
	//take the complete n-oligo table as input; here, hexamers of 6nt are passed from the caller
	//	int n = 6; //for this program, we divide the octamer into 2 6-mers.
	
	vector<string> n_mer_list; //this is the result tabel that will be built

	for (vector<string>::size_type i = 0; i<noligos.size(); i++)
	{//for each n-mer in the input table, which is a complete enumeration of n-oligos
		string current_n_mer = noligos[i];
		int current_n_mer_list_size =  noligos.size();
	//	cout<<"current n-mer is number: " <<i+1<<" of "<<current_n_mer_list_size<<" total temp_list entries."<<endl;
		//cout.flush();

		for (vector<site_in_gene>::size_type j = 0; j < sitesInGene.size(); j++){
		//for each site struct in the sites table of the current gene

		//	string current_targetsite = sitesInGene[j];
			//cout<< "current target site is: "<< current_targetsite << endl;
		//	int yes = MNxmer_match (3, current_n_mer, sitesInGene[j]); //starting at the 11th nt, length 8, but the indeces are in the target
			int yes = MNxmer_tiling_oneside(4, current_n_mer, sitesInGene[j]);
			if (yes > 0)
			{
				n_mer_list.push_back(current_n_mer);
			//	cout<<"Current 6mer is good for current site "<<sitesInGene[j]<<endl;
		//		cout<<"HIT!"<<'\t'<<noligos[i]<<'\t'<<sitesInGene[j]<<endl;
				break;//skip the rest of the sites for the same gene and move on to the next 8-mer. 
				//As long as there is a match to any site in the gene, no matter where the match is, the current n-mer is saved.
			}//if
		}//for each site

	}//fore each octamer
	return n_mer_list;
}//update_temp8mers

int SeedOctamer::MNxmer_match(int x, string M_mer, string N_mer){
	int match_window_size = x; //using 3-mer tiling for the match.
	Complementer wobchecker;

	int x_match = 0; //the return result is initialized to 0; return 1 if a match is found.
	//int match_counts = 0; //counting how many wobble matches in total. 

	for (string::size_type i = 0; i <= M_mer.size()-match_window_size; i++){//for each 3mer from the octamer
	
		string trimer_in8mer = M_mer.substr(i, match_window_size); //store the current sliding 3mer from 8mer
		for (string::size_type j = 0; j <= N_mer.size()-match_window_size; j++){//for each 3mer from the target site subseq
		
			string trimer_insite = N_mer.substr(j, match_window_size);
		//	if (wobchecker.isWobbleComp(trimer_in8mer, trimer_insite) == 1){
			if (wobchecker.isWatsonCrick(trimer_in8mer, trimer_insite)==1){

				x_match = 1;
				break; 
				//if a match is found, skip the rest of the matching combinations; 
				//this only breaks out of the inner loop. Another conditional break for the outer loop

			//	match_counts++;	 
			}//if a match is found

		}//for each site_subseq
		if(x_match == 1){
			//cout<<"trimer match."<<endl;
			break;//break out of the outer loop, move to the next octamer.
		}//if

	}//for each octamer

	return x_match;
}

int SeedOctamer::MNxmer_tiling_oneside(int x, string target_M_mer, string oligo_N_mer){
	//resturns 1 if a continuous 4 base pairing, including Wobble pairing, exists in the target. 
	//In the oligo, don't care if continuous or not.
	//x is the stretch size that need to be continuously paired.

	//declare output
	int x_match = 0; //returns how many 4-mer pairings are found in the target M-mer. This is the score

	Complementer wobchecker;

	//int match_counts = 0; //counting how many wobble matches in total. 

	for (string::size_type i = 0; i <= target_M_mer.size()-x; i++){//for each 4mer from the octamer
		string target_xmer = target_M_mer.substr(i, x); //4mer in target
		
		
		int continous_count = 0;
		int target_xmer_index =0;

		for (int k = 0; k < oligo_N_mer.length(); k++){
			
			//	cout<<"target_xmer "<<target_xmer.substr(j, 1)<<endl;
			//	cout<<"oligo_nmer "<<oligo_N_mer.substr(k,1)<<endl;
			if (target_xmer_index >= target_xmer.length()){//if the target xmer is finished, break out of the inner loop.
				break;
			}
			else if (wobchecker.isWobbleComp(target_xmer.substr(target_xmer_index, 1), oligo_N_mer.substr(k,1)) == 1){
					continous_count++;
					target_xmer_index++;		
				}

		}//for k
			//if a stretch of 4 nt in target is paired by oligo, break out of the inner loop
		if (continous_count == x){//the maximum pairing we can have is the same as the length of the xmer
			x_match ++;
		//	break;
		}//if a xmer pair is found

	}//for i

	return x_match;
}

int SeedOctamer::MNxmer_score(int x, string M_mer, string N_mer){
	int match_window_size = x; //using 3-mer tiling for the match.
	Complementer wobchecker;

	//int x_match = 0; //the return result is initialized to 0; return 1 if a match is found.
	int match_count = 0; //counting how many wobble matches in total. 
	int j = 0;
	for (string::size_type i = 0; i <= M_mer.size()-match_window_size; i++){//for each 3mer from the octamer
	
		string trimer_in8mer = M_mer.substr(i, match_window_size); //store the current sliding 3mer from 8mer
		for (string::size_type j = 0; j <= N_mer.size()-match_window_size; j++){//for each 3mer from the target site subseq
		
			string trimer_insite = N_mer.substr(j, match_window_size);
//			if (wobchecker.isWobbleComp(trimer_in8mer, trimer_insite) == 1){//1 point for wobble pairs
	//			match_count++;

				if (wobchecker.isWatsonCrick(trimer_in8mer, trimer_insite)==1){

					match_count++;
		//			match_count = match_count +  2;//additional award if wantson-crick 
					j++;//move down to next 3-mer.

				}//and if wc- match is found

		}//for each 3mer in N-mer

	}//for each 3-mer in the M-mer oligo

	return match_count;
}

vector<seed_gene_site_score> SeedOctamer::NmerScoreTarget(vector<seed_octamer> seedOctamers_table, vector<common_seed_info> common_seeds){
	//The nmers were selected from a complete enumertion by comparing if there is 1 match (3mer) in any target sites in all genes.
	//Now this method finds all the target sites in all genes with this seed.
	vector<seed_gene_site_score> seed_8mer_scores;//declare output table

	for (vector<seed_left_right>::size_type i = 0; i< seedOctamers_table.size(); i++){//for each seed-hexamer entry
		
		seed_gene_site_score current_sss;
		current_sss.seed_seq = seedOctamers_table[i].seedseq;

		for (vector<common_seed_info>::size_type j = 0; j<common_seeds.size(); j++){//for every seed in the common seed table
			vector<siteinfo> common_seed_gene_sites;

			if (seedOctamers_table[i].seedseq.compare(common_seeds[j].seed_sequence)==0){//if the seed is found in the common seed table
				
				common_seed_gene_sites = common_seeds[j].site_list; //copy all the sites in this gene to current entry
					
				current_sss.seedgenesite_scores = produce_nmerScores(seedOctamers_table[i].octamerList, common_seed_gene_sites);

				break; //if a seed is found in the common seed table, skip the rest of the entries after the scores are calculated.
						//Skip the rest b/c each seed in the common table is unique, no need to check the rest.
			}//if the seed of the hexamer table is found in the common seed table

		}//for each entry(seed) in the common seed table
		seed_8mer_scores.push_back(current_sss);//save the new element: current seed site score (sss)
	}//for each seed in the hexamer table
	return seed_8mer_scores;
}

vector<GeneScore> SeedOctamer::produce_nmerScores(vector<string> octamers, vector<siteinfo> seedSiteInfotable){
	//this method produces list of scores of each nmer on each target in each gene
	vector<GeneScore> octamerScoreTable;//declare output

	for (int i = 0; i < octamers.size(); i++){//for each entry in the hexamer list
		string current_hexmer = octamers[i];

		GeneScore current_hexamerGeneSiteScore;
		current_hexamerGeneSiteScore.hexamer = current_hexmer;

		octamerScoreTable.push_back(current_hexamerGeneSiteScore);//create a new entry with each hexamer, fill the rest: vector
		
		//vector<site_in_gene> target_list =seedSiteInfotable;
		for (vector<siteinfo>::size_type j = 0; j<seedSiteInfotable.size();j++){//for each gene in the site info table
			string current_gene_name = seedSiteInfotable[j].gene_id;
			gene8merSiteScore current_geneSiteScore;
			current_geneSiteScore.gene_name = current_gene_name;
			octamerScoreTable[i].genesite_scores.push_back(current_geneSiteScore); 

			for (vector<site_in_gene>::size_type k = 0; k<seedSiteInfotable[j].gene_site_table.size(); k++){//for each site in the gene

				target_score current_target_score;

				string current_target_site = seedSiteInfotable[j].gene_site_table[k].site_sequence;
				int target_pos = seedSiteInfotable[j].gene_site_table[k].start_pos;

				string targetSubstring;
				targetSubstring = current_target_site.substr(10,6);//define the BC region against which the hexamer will be designed

			//	int current_score = MNxmer_score(3, current_hexmer, targetSubstring);//3mer matching counts, some of them will be 0
				int current_score = MNxmer_tiling_oneside(3, current_hexmer, targetSubstring);

				current_target_score.target_seq = current_target_site;
				current_target_score.score = current_score;
				current_target_score.target_substring = targetSubstring;
				current_target_score.pos = target_pos;

				octamerScoreTable[i].genesite_scores[j].site_scores.push_back(current_target_score);
			
			}//for each site in the gene 

		}//for each gene	
	
	}//for each hexamer

	return octamerScoreTable;
}



vector<seed_nmer_info> SeedOctamer::list_bulge_tail(vector<seed_gene_site_score> seed_nmer_gene_score_list){
	//This method builds a list of seed/n-mer/bulge/tail combination that binds to target sites (hits-only).
	//This method defines the central bulge and tail region by postion index and length in the total target site.

	vector<seed_nmer_info> bulge_tail_list; //construct this data structure while going through the viable seed table level by level

	//string concensus_bulge, concensus_tail;

	for (vector<seed_gene_site_score>::size_type i = 0; i < seed_nmer_gene_score_list.size(); i++) {
		//for each seed in the viable seed table
		seed_nmer_info current_seed_nmer;
		
		current_seed_nmer.seed_seq = seed_nmer_gene_score_list[i].seed_seq;

		vector<nmer_concensus> nmer_hittargets;

		for (vector<GeneScore>::size_type j = 0; j< seed_nmer_gene_score_list[i].seedgenesite_scores.size(); j++){
		//for each hexamer/n-mer of the viable seed
			string nmer_seq = seed_nmer_gene_score_list[i].seedgenesite_scores[j].hexamer;
			nmer_concensus current_nmer_concensus;

			current_nmer_concensus.nmer = nmer_seq;

			vector <target_seq_info> nmer_bulgetail_table;
			
			target_seq_info current_bulgetail;

			for (vector<gene8merSiteScore>::size_type k = 0; k<seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores.size(); k++){
			//for each gene

				current_bulgetail.gene_name = seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores[k].gene_name;

				for (vector<target_score>::size_type l = 0; l < seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores[k].site_scores.size(); l++){
				//for each target site
					if (seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].score > 0){
						//only use the target sequences that are hit by the n-mer to construct bulges and tails.!!!
						string current_targseq = seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].target_seq;
						current_bulgetail.target_seq = current_targseq;

						int current_site_pos =  seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].pos;
						current_bulgetail.target_pos = current_site_pos;

						current_bulgetail.central_bulge = current_targseq.substr(16,3);//BC 4mer:bulge(15, 4); BC 6mer: bulge(16, 3); BC 8mer: bulge(17, 2);
						current_bulgetail.tail = current_targseq.substr(6,4);//BC 4mer: tail(6, 5); BC 6mer: tail(6, 4); BC 8mer: tail(6,3);
						
						current_bulgetail.score = seed_nmer_gene_score_list[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].score;

						nmer_bulgetail_table.push_back(current_bulgetail);
					}//if the target site sequence is a hit

				}//for l
				
			}//for k
			current_nmer_concensus.concensus_seq_table = nmer_bulgetail_table;

			nmer_hittargets.push_back(current_nmer_concensus);

		}//for j

		current_seed_nmer.nmer_concensus_table = nmer_hittargets;

		bulge_tail_list.push_back(current_seed_nmer);


}//for i


return bulge_tail_list;

}//list bulge tail

vector<seed_bulge_tail> SeedOctamer::seed_nmer_bulge_tail_concensus(vector<seed_nmer_info> input_all_bulgetails){
	//This method builds a concensus sequence of bulge and tail from all "hit" bulges and tails that share the same seed and n-mer.
	//hence there is only one nmer-bulge-tail combination, but multiple targets!!!

	vector<seed_bulge_tail> concensus_bulgetails;
	
	for (int i = 0; i<input_all_bulgetails.size(); i++){
		seed_bulge_tail curr_seed_nmer_bulge_tail;
		curr_seed_nmer_bulge_tail.seed_seq = input_all_bulgetails[i].seed_seq;
		

	//	string curr_nmer;
		for (int j = 0; j < input_all_bulgetails[i].nmer_concensus_table.size();j++){
			vector<nmer_bulge_tail> current_nmer_bulgetails;
			nmer_bulge_tail curr_nmer_bulge_tail;

			curr_nmer_bulge_tail.nmer = input_all_bulgetails[i].nmer_concensus_table[j].nmer;

			vector<string> curr_bulges, curr_tails;//data structure needed for bulding the concensus
			string nmer_bulge, nmer_tail; //output data structure for the concensus

			vector<string> genes;
			vector<int> target_positions;
			vector<string> targets;	
			vector<int> scores;

			for (int k = 0; k<input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table.size();k++){

				curr_bulges.push_back( input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table[k].central_bulge);
				curr_tails.push_back (input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table[k].tail);

				target_positions.push_back(input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table[k].target_pos);
				targets.push_back(input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table[k].target_seq);
				genes.push_back(input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table[k].gene_name);
				scores.push_back(input_all_bulgetails[i].nmer_concensus_table[j].concensus_seq_table[k].score);

			}//for k, make 2 string vectors that contain all central bulges and all tails of a given n-mer

			//compute the concensus bulge and tail
			nmer_bulge = compute_concensus_string(curr_bulges);
			nmer_tail = compute_concensus_string(curr_tails);

			//Now ready to construct current n-mer bulge_tail entry in the concensus_nmer_bulge_tail table
			curr_nmer_bulge_tail.bulge = nmer_bulge;//construct bulge part of the struct
			curr_nmer_bulge_tail.tail = nmer_tail;//construct the tail part of the struct

			curr_nmer_bulge_tail.gene_names = genes;
			curr_nmer_bulge_tail.target_positions = target_positions;//list of target positions
			curr_nmer_bulge_tail.targets = targets;//list of target sequences
			curr_nmer_bulge_tail.trimatch_scores = scores; //list of scores
			
			//save this in the current_nmer_bulgetails list, for this nmer. Each seed corresponds to multipole nmers, each nmer gets this list
			current_nmer_bulgetails.push_back(curr_nmer_bulge_tail);//save the struct on the vector

			//assign the current temporary bulgetails vector to the vector part of the output list, the seed part has alrady been assigned at the beginning
			curr_seed_nmer_bulge_tail.bulgetails = current_nmer_bulgetails;//construct the vector part of the struct

			//Last step, save the seed-nmer combination entry in the output vector: concensus_bulgetails, there are iXj entries.
			concensus_bulgetails.push_back(curr_seed_nmer_bulge_tail); //save this struct to the output vector
		}//for j

	}//for i

	return concensus_bulgetails;
}

string SeedOctamer::compute_concensus_string(vector<string> seqs){
	//all input strings must have the same length
	string conc_seq = "";	
	int len = seqs[0].length();
	
	for (int i = 0; i<len; i++){
		conc_seq.append(compute_concensus(seqs, i));
	}
	return conc_seq;

}

string SeedOctamer::compute_concensus(vector<string> input_strings, int pos){
	//string nucleotide;

	struct nt_count{
		string nucleotide;
		int count;
	};

	vector <nt_count> all_counts;

	nt_count A_count, C_count, G_count, T_count;

	A_count.nucleotide = "A";
	A_count.count = 0; 
	all_counts.push_back(A_count);

	C_count.nucleotide = "C";
	C_count.count = 0; 
	all_counts.push_back(C_count);

	G_count.nucleotide = "G";
	G_count.count = 0; 
	all_counts.push_back(G_count);

	T_count.nucleotide = "T";
	T_count.count = 0; 
	all_counts.push_back(T_count);



	for (int i = 0; i < input_strings.size(); i++){
		string curr_char = input_strings[i].substr(pos,1);
		for (vector<nt_count>::size_type j = 0; j<all_counts.size(); j++){
			if (curr_char.compare( all_counts[j].nucleotide) == 0 ){
				all_counts[j].count++;
				break;
			}//if
		
		}//for j
	}//for each string in the input string vector

/******
	for (int i = 0; i<all_counts.size();i++){
		cout<< all_counts[i].nucleotide<<'\t'<<all_counts[i].count<<endl;
	}
/****/

	nt_count max;
	
	max.count = all_counts[0].count;
	max.nucleotide = all_counts[0].nucleotide;
	for (vector<nt_count>::size_type j = 0; j<all_counts.size(); j++){//find the nucleotide with max count
		if (max.count < all_counts[j].count){
			max.count = all_counts[j].count;
			max.nucleotide = all_counts[j].nucleotide;
		}//if
	}//for j
//	cout<<max.nucleotide<<'\t'<<max.count<<endl;
	return max.nucleotide;

}



/**************Below are functions for two half hexamer table scoring****************************/

vector <seed_octamer> SeedOctamer::listNmersLR (vector<common_seed_info> input_table, vector<string> allNmers){
	
//	vector<seed_nmer> seed8mer_table;  //this is the output of this function that will be built 


	vector<seed_octamer> seed_8mer_table, left_nmer_table, right_nmer_table;
	seed_octamer current, current_right;
	//build the current entry in the result table; 
	//this data structure is used to construct the 8mer table.

	vector<seed_left_right> seed_hexamers; //for saving both left and right 6mer table for each seed.
	seed_left_right current_slr; //current entry of seed_left_right table;
	

	//note: "left" refers to the region that is closer to the seed and "right" refers to the farther one.
	//hence, in the site that is 27 nt long, left is between 9 and 14, right is between 11 and 16

	for (vector<common_seed_info>::size_type i = 0; i<input_table.size();i++){
		//for each seed in the common_seed_list table, if at least 1 8-mer is found for all gens, 
		//convert to its complement sequences and save this seed with its octmer list
		
		current.seedseq = input_table[i].seed_sequence;
	
		/****convert the seed in mRNA into complement for siRNA 
		Complementer seed_comp;
		current.seedseq = seed_comp.get_complement(input_table[i].seed_sequence);
		***/
		current_slr.seed_seq = current.seedseq; //set the seed sequence for the current slr table.

		cout<<"current seed is (3' to 5'direcion, complement of mRNA): "<<current.seedseq<<endl;

		vector<string> temp_nmer_leftlist = allNmers;
		
		//initialize the temp n-mer list to the complete table of n-mers
		//this list will be updated when going through each gene in the stie list.
		
		for (vector<siteinfo>::size_type j = 0; j < input_table[i].site_list.size(); j++){
		//for each gene in the sitelist of the seed

			siteinfo targets_in_gene = input_table[i].site_list[j]; //this contains both the gene name and the site list.
			vector<site_in_gene> sites = input_table[i].site_list[j].gene_site_table;
			
			string current_gene = input_table[i].site_list[j].gene_id;

			//construct 6-mer substring of the targe sites of a given gene. The left half.
			vector <string> left_list = make_nmer_sitelist(targets_in_gene, 11, 6);


			cout<<"start updating the temp_left_list for the current gene: "<<current_gene<<endl;

			temp_nmer_leftlist = update_n_mers(temp_nmer_leftlist, left_list); 

			//builds a new temp list with at least one hit in any site subsequence.

		}//for each gene, construct the left half 6-mer table
		
		vector<string> temp_nmer_rightlist = allNmers;

		for (vector<siteinfo>::size_type j = 0; j < input_table[i].site_list.size(); j++){
		//for each gene in the sitelist of the seed

			siteinfo targets_in_gene = input_table[i].site_list[j]; //this contains both the gene name and the site list.
			vector<site_in_gene> sites = input_table[i].site_list[j].gene_site_table;
			
			string current_gene = input_table[i].site_list[j].gene_id;
		
			vector <string> right_list = make_nmer_sitelist(targets_in_gene, 9, 6);//the right half

			cout<<"start updating the temp_right_list for the current gene: "<<current_gene<<endl;

			temp_nmer_rightlist = update_n_mers(temp_nmer_rightlist, right_list); 
			//builds a new temp list with at least one hit in any site subsequence.

		}//for each gene, construct the right half 6mer table.

		current_slr.left = temp_nmer_leftlist;
		current_slr.right = temp_nmer_rightlist;
		seed_hexamers.push_back(current_slr); 

		current.octamerList = construct_8mer_table(temp_nmer_leftlist, temp_nmer_rightlist);
		//construct the octamer list for the current seed
		
		if (current.octamerList.size() > 0) {
			seed_8mer_table.push_back(current); //save this entry into the result table if the 8mer list is not empty
			cout<<"Finished "<< i+1 << " of "<< input_table.size()<<" seeds from the common seed table for octamer search."<<endl;
		}//save only the seeds with non-empty 8mer lists

	}//for each seed

	set_slr_table(seed_hexamers); 
	//call the method that saves the seed_left_right table in a data structure.

	return seed_8mer_table;

}//method listOctamers

vector<string> SeedOctamer::construct_8mer_table(vector <string> left, vector<string> right){
	//this metho construct a list of octamers using 2 lists of n-mers with x-mer overlap in between, 
	//i.e., if the last x-mer of the left string is the same as the first x-mer of the right string,
	//assemble them into a new string.
	int overlap = 4; //define the overlapping string length

	vector<string> assembled8mers;
	//declare the output data structure as a vector of 8mers.

	for (int i = 0; i<left.size(); i++){
	//for every entry in the left table
	string left_string = left[i];

		for(int j = 0; j<right.size(); j++){
		//for every entry in the right table
			string  right_string = right[j];

			string assembled = mergeLeftRight(left_string, right_string, overlap);
			assembled8mers.push_back(assembled);
		}//for j
	}//for i
	return assembled8mers;
}//construct 8mers

string SeedOctamer::mergeLeftRight(string left_string, string right_string, int overlap){//merge two strings based on an overlapping sequnce.

	string assembled;

	int left_len = left_string.size();

	string last_x_OfLeft = left_string.substr(left_len - overlap, overlap); 
			
	int right_len = right_string.size();
	string first_x_OfRight = right_string.substr(0, overlap);

	if (last_x_OfLeft.compare(first_x_OfRight)==0) {
				//if the last 4 of the left is the same as the first 4 of the right, 
				//then assemble them and save the int the output vector.

				//The assembly is done by concatenating the entire left string with the non-overlap 
				//part of the right string
	assembled = left_string + right_string.substr(overlap, right_len-overlap);
					
	}//if
	
	/***
	else {
	assembled = "N";//a null string returned as a check for no overlap n-mers between left and right.
	
	}
	***/

	return assembled;
}

void SeedOctamer::set_slr_table(vector<seed_left_right> input){
	seed_hexamers = input;
}

vector<seed_site_score> SeedOctamer::oligoScoreTarget(vector<seed_left_right> hex_half_table, vector<common_seed_info> common_seeds){
	vector<seed_site_score> seed_6mer_scores;//declare output table
	
	vector<seed_left_right> seedLR;

	vector<string> current_left_6mers, current_right_6mers; 

	for (vector<seed_left_right>::size_type i = 0; i< hex_half_table.size(); i++){//for each seed-hexamer entry

		
		seed_site_score current_sss;
		current_sss.seed_seq = hex_half_table[i].seed_seq;

	//	seed_6mer_scores.push_back(current_sss);

		for (vector<common_seed_info>::size_type j = 0; j<common_seeds.size(); j++){
			vector<siteinfo> common_seed_gene_sites;

			if (hex_half_table[i].seed_seq.compare(common_seeds[j].seed_sequence)==0){//if the seed is found in the common seed table
				
				common_seed_gene_sites = common_seeds[j].site_list;
					
				current_sss.left_hex_site_scores = produce_moiety_6merScores(hex_half_table[i].left, common_seed_gene_sites, "left");
				current_sss.right_hex_site_scores = produce_moiety_6merScores(hex_half_table[i].right, common_seed_gene_sites, "right");	

				break; //if a seed is found in the common seed table, skip the rest of the entries after the scores are calculated.
			}//if the seed of the hexamer table is found in the common seed table

		}//for each entry(seed) in the common seed table
		seed_6mer_scores.push_back(current_sss);//save the new element: current seed site score (sss)
	}//for each seed in the hexamer table
	return seed_6mer_scores;
}

vector<hexamerGeneScore> SeedOctamer::produce_moiety_6merScores(vector<string> leftorright, vector<siteinfo> seedSiteInfotable, string half){
	vector<hexamerGeneScore> halfScoreTable;//declare output

	for (int i = 0; i < leftorright.size(); i++){//for each entry in the hexamer list, either left or right half
		string current_hexmer = leftorright[i];

		hexamerGeneScore current_hexamerGeneSiteScore;
		current_hexamerGeneSiteScore.hexamer = current_hexmer;
		halfScoreTable.push_back(current_hexamerGeneSiteScore);//create a new entry with each hexamer, fill the rest: vector
		
		//vector<site_in_gene> target_list =seedSiteInfotable;
		for (vector<siteinfo>::size_type j = 0; j<seedSiteInfotable.size();j++){//for each gene in the site info table
			string current_gene_name = seedSiteInfotable[j].gene_id;
			geneSiteScore current_geneSiteScore;
			current_geneSiteScore.gene_name = current_gene_name;
			halfScoreTable[i].gene_scores.push_back(current_geneSiteScore); 

			for (vector<site_in_gene>::size_type k = 0; k<seedSiteInfotable[j].gene_site_table.size(); k++){//for each site in the gene

				target_hex_score current_target_hex_score;

				string current_target_site = seedSiteInfotable[j].gene_site_table[k].site_sequence;
				int target_pos = seedSiteInfotable[j].gene_site_table[k].start_pos;
				string targetSubstring;

				if (half == "left"){
					targetSubstring = current_target_site.substr(11,6);
				}
				else if (half == "right"){
					targetSubstring = current_target_site.substr(9,6);
				}
				int current_score = MNxmer_score(3, current_hexmer, targetSubstring);
				
				current_target_hex_score.score = current_score;
				current_target_hex_score.target_substring = targetSubstring;
				current_target_hex_score.pos = target_pos;

				halfScoreTable[i].gene_scores[j].site_scores.push_back(current_target_hex_score);
			
			}//for each site in the gene 

		}//for each gene	
	
	}//for each hexamer

	return halfScoreTable;
}


