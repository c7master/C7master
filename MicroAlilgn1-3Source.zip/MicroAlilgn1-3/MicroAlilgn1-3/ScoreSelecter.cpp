#include  "ScoreSelector.h"

//This class take the output from the the AssembleAligned class, which contains the designed siRNAs
//and their targets, along with the alignment strings and symbols and the scores, then choose the 
//candidate "hits" according the distribution of the high scores in among the targets according
//to a distribution function.

//The primary criterion is just to filter out the low scorers below a pre-determined threshold. 
//The selected ones will go through next stage of selection by ranking the off-targets. Another
//class will take care of this function



vector<caltarget> ScoreSelector::select_siRNAs(vector<siRNA_target_align> align_results){ //master method that calls all others: clauclate total, calculate average, sort vector of struct
	//User-defined score threshold for the efficiency of siRNA
	vector<caltarget> selected;
	caltarget siRNAhit;

	//set up selection parameters
	vector<caltarget> cal_siRNAs; //siRNAs with their targets and calculated miScores.	
	cout<<"calculating total miScores for each siRNA..."<<endl;
	cout<<"Total number of alignments: "<<align_results.size()<<endl;
	cal_siRNAs = calScores(align_results); //get the total and averages
	cout<<"calculation of total miScores finished."<<endl;

	//need to determine the number of maximum targets for selction criteria;
	//initialize the parameters
	cout<<"calculating maximum target number."<<endl;
	int ID = align_results[0].siRNA_index;
	int max_targnum = 0; //the first target name counts as 1
	string targName = align_results[0].target_information.gene_name; //store the first target name
	
	for (int i = 0; i<align_results.size(); i++){

		if (align_results[i].siRNA_index == ID){//for all entries with the same siRNA ID
			if (align_results[i].target_information.gene_name.compare(targName)!=0){//if a new target name
				max_targnum ++;
			}//if a new target gene name appears, increment
		}//if we are still looking at the first siRNA in the align_result list

		else break; //skip all other siRNAs, the number of total targets is the same for all of them.
	
	}//for
	cout<<"max target number calculated: "<<max_targnum<<endl;

	cout<<"Saving selected siRNAs in a new list..."<<endl;
	for (int i = 0; i<cal_siRNAs.size();i++){ //for every entry of the calculated list of siRNA and targets
		if (cal_siRNAs[i].target_counts = max_targnum){// if all targets are hit
			//store the siRAN and all targets in the output list
			siRNAhit = cal_siRNAs[i]; 
			cout<<"siRNA ID"<<siRNAhit.siRNA_ID<<"target number "<<cal_siRNAs[i].target_counts<<endl;
			
			selected.push_back(siRNAhit);
		}
	}//for each entry in cal_siRNA, store the entries that are have higher-than-threshold for all targets in a new vector: selected
	cout<<"Saving completed."<<selected.size()<<endl;

	cout<<"sorting selection list..."<<endl;
	sort(selected.begin(), selected.end(), MyPredicate());
	cout<<"selection list sorted."<<endl;
	return selected;
}

vector <caltarget> ScoreSelector::calScores (vector<siRNA_target_align> align_results){ //calculates the total score
	
	//declare output 
	vector<caltarget> allTargetScores;
	
	double total = 0.00;
	double threshold = 87.0; //everything > 87 will be accepted	
	int current_ID = 0; //keep track of the index of siRNAs, only calculate for those that have identical IDs.
	int target_count = 0;

	caltarget curr_scores;
	curr_scores.siRNA_ID = 0;
	curr_scores.target_counts = 0;
	curr_scores.total_above_miScore = 0;
	curr_scores.average_above_miScore = 0;

//	int i = 0;
//	while(i<align_results.size()){
	for (int i =0; i<align_results.size(); i++){

		current_ID = align_results[i].siRNA_index;

		if (current_ID == curr_scores.siRNA_ID){//not a new entry

			if (i == align_results.size()-1){//if not a new siRNA but the last entry in the table, store the values
				
				if (align_results[i].al_result.miScore > threshold){
					total = total + (double)align_results[i].al_result.miScore;
					if (align_results[i].target_information.gene_name.compare(align_results[i-1].target_information.gene_name)!=0){
						//if this is a different gene target than the last
						target_count++;
					}
				}//if the score is above the threshold
				
				curr_scores.target_counts = target_count;
				curr_scores.total_above_miScore = total;
			//	curr_scores.average_above_miScore = (double) total/target_count;
				allTargetScores.push_back(curr_scores);
				//print out test
				cout<<"siRNA: "<<curr_scores.siRNA_ID<<'\t'<<"Targets "<<curr_scores.target_counts
				<<"Total miScore "<<curr_scores.total_above_miScore<<endl;
			}//last entry in the table, store info


			else //not a new siRNA entry and not the last entry in the table
				if (align_results[i].al_result.miScore > threshold){
				total = total + (double)align_results[i].al_result.miScore;
				if (align_results[i].target_information.gene_name.compare(align_results[i-1].target_information.gene_name)!=0){
						target_count++;
					}//if a different target name from the previous one
			}//score greater than threshold
		}//if not a new siRNA

		else {//else if a new siRNA
			if (i == 0 ){//if this is the first siRNA, then don't store anything, just increment if necessary
					if (align_results[i].al_result.miScore > threshold){
						total = total + (double)align_results[i].al_result.miScore;	
						target_count++;
					}//if above threshold
			}//if first siRNA

			else {//else if this is not the first siRNA, calculate all information for the previous siRNA and store information
				//calculate all entries and save the previous siRNA info on output vector
				curr_scores.siRNA_seq = align_results[i].siRNA;
				curr_scores.target_counts = target_count;
				curr_scores.total_above_miScore = total;
			//	curr_scores.average_above_miScore = (double) total/target_count;
				allTargetScores.push_back(curr_scores);
				//print out test
		//		cout<<"siRNA: "<<curr_scores.siRNA_ID<<'\t'<<"Targets "<<curr_scores.target_counts
		//		<<"Total miScore "<<curr_scores.total_above_miScore<<endl;
			
				//reset temp variables
				curr_scores.siRNA_ID = current_ID;
				total = 0;
				target_count = 0;

				if (align_results[i].al_result.miScore > threshold){
					total = total + (double)align_results[i].al_result.miScore;
					target_count++;
				}//if above threshold, increment

			}//else, not the first and a new siRNA, store previous info, reset parameters, increment if necessary
		}//else if a new siRNA
//		i++;
	}//while more entries in the align_result table

/******
	for(int i = 0; i<align_results.size(); i++){//construct a list of unique siRNAs and their targets and relavent information


		cout<<"going through align_results..."<<current_ID<<endl;

		if (align_results[i].siRNA_index != current_ID){//if we are looking at a new entry

			//store the previous entry if its siRNA ID is not 0;
			if (current_ID != 0){
				allTargetScores.push_back(curr_scores);	
				cout<<"Saving siRNA: "<< curr_scores.siRNA_ID<<'\t'<<"target counts: "<<curr_scores.target_counts<<'\t'<<"Average Score "<<curr_scores.average_above_miScore<<endl;
			}

			current_ID = align_results[i].siRNA_index;
			cout<<"New siRNA ID: "<< current_ID<<endl;
			total = 0; //clear the current total for incrementation
			target_count = 0;

			//

		//	curr_scores.sitarinfo.push_back(align_results[i]); //copy all align_results
			curr_scores.siRNA_ID = align_results[i].siRNA_index; //constructing the current entry struct for the output

			int curr_miScore = align_results[i].al_result.miScore; //copy miScore
			if (curr_miScore > threshold){ //if the target scores above the threshold, increment count and total scores	
				//update the entry for total, average and target counts.
				total += curr_miScore; //increment 
				curr_scores.total_above_miScore = total;
				target_count++;		
				curr_scores.target_counts = target_count;
				curr_scores.average_above_miScore = (double)total/target_count; 

			//	cout<<current_ID<<endl;
			}
			
		//	allTargetScores.push_back(curr_scores);
		}//if a new entry

		else{ //not a new entry

		//	curr_scores.sitarinfo.push_back(align_results[i]); //copy all align_results

			int curr_miScore = align_results[i].al_result.miScore; //copy miScore
			if (curr_miScore > threshold){ //if the target scores above the threshold, increment count and total scores	
				//update the entry for total, target counts and averages.
				total += curr_miScore; //increment 
				curr_scores.total_above_miScore = total;
				target_count++;		
				curr_scores.target_counts = target_count;
				curr_scores.average_above_miScore = (double)total/target_count; 
				
			}//if above the threshold

		}//not a new entry
	
	}//for each 
******/
	return allTargetScores;

}//calscores



double ScoreSelector::get_average_aboveScore(double total, int count){ //calculate the average score for each siRNA
	double average_score;
	
	return average_score;

}


vector <caltarget> ScoreSelector::skimtop(vector<caltarget> all_calculated){ //takes all the siRNAs with calculated scores and return the ones with top scores. 
	vector<caltarget> tophits;

	return tophits;
}

/*****
bool sortByTotalScores(const caltarget& siRNA1, const caltarget& siRNA2){ //user-defined comparsion function for sortiing the vector<caltarget>
	if (siRNA1.total_above_miScore != siRNA2.total_above_miScore){
		return(siRNA1.total_above_miScore < siRNA2.total_above_miScore);
	}

}
****/