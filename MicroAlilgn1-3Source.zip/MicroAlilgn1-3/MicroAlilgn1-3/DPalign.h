using namespace std;
#include <string>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>