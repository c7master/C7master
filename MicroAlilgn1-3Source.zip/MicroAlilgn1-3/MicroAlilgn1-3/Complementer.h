using namespace std;

#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

class Complementer{
public:
	string complementDNA;
	string get_complement(string DNA_comple);
	int isWobbleComp (string, string);
	int isWatsonCrick(string, string);
};