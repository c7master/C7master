using namespace std;
#include <string>
#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>

#ifndef SUBSEQLISTER_H
#define SUBSEQLISTER_H
#include "SubseqLister.h"
#endif


struct site_in_gene {
	int start_pos;
	string site_sequence;
};//struct1

struct siteinfo{
	string gene_id;
	vector <site_in_gene> gene_site_table;//vector1 of struct1
};//struct2 of {gene_name, vector1}

struct common_seed_info {
	string seed_sequence;
	vector <siteinfo> site_list; //vector2 of struct2
};//struct3 of {seed_seq, vector2}

//vector3 of strut2 is delcared in the class function, in .cpp file.

class CommonSiteFinder {
public:
	vector <common_seed_info> find_common_seed_sites(vector <slidingWin_seqlist>);
	void error_message();
	vector <string> remove_redundant (vector <string> input_vector);
	vector<string> make_2gene_seedlist(vector <slidingWin_seqlist>);
	vector<string> make_moregene_seedlist(vector <slidingWin_seqlist>, vector<string>);
	vector<common_seed_info> construct_info_table(vector<string>, vector<slidingWin_seqlist>);
	int get_window_size(vector <slidingWin_seqlist> slidesitelist);
	int get_start_pos(vector <slidingWin_seqlist> slidesitelist);
	vector<string> remove_polyA(vector<string> seedlist);
};