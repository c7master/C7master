#include "FileWriter.h"


void FileWriter::storeCommonSeeds(string file_name1, vector<common_seed_info> common_seeds){
	ofstream myfile;
	myfile.open(file_name1);
	for(int i = 0; i<common_seeds.size(); i++){
	
		myfile<<common_seeds[i].seed_sequence<<endl;
		
		for (int j = 0; j<common_seeds[i].site_list.size();j++){
			myfile<<'\t';
			myfile<<common_seeds[i].site_list[j].gene_id<<endl;
			

			for (int k = 0; k < common_seeds[i].site_list[j].gene_site_table.size();k++){
				myfile<<'\t';
				myfile<<'\t';
				myfile<<common_seeds[i].site_list[j].gene_site_table[k].start_pos<<'\t'
					<<common_seeds[i].site_list[j].gene_site_table[k].site_sequence<<endl;
			//	myfile<<'\t';

			}//for each target site in the current gene


		}//for each gene
	
	}//for each seed in the list
	myfile.close();


}
	
void FileWriter::storeOctamers(string file_name2, vector<string> octamers){
	ofstream myfile;
	myfile.open(file_name2);
	for(int i = 0; i<octamers.size(); i++){
	
		myfile<<octamers[i]<<endl;
	
	}
	myfile.close();
}


void FileWriter::storeSeedOctamers(string file_name3, vector<seed_octamer> viableseed_octamers){
	ofstream myfile;
	myfile.open(file_name3);
	for(int i = 0; i<viableseed_octamers.size(); i++){
	
		myfile<<viableseed_octamers[i].seedseq<<endl;
		for(int j = 0; j < viableseed_octamers[i].octamerList.size(); j++){
			myfile<<'\t'<<viableseed_octamers[i].octamerList[j]<<endl;
		}//for each octamer in the lest
	
	}//for each seed

	myfile.close();
}

void FileWriter::storeHexamerScores(string file_name4, vector<seed_site_score> seed_scores_LR){
	ofstream myfile;
	myfile.open(file_name4);
	for(vector<seed_site_score>::size_type i = 0; i<seed_scores_LR.size(); i++){
	
		myfile<<seed_scores_LR[i].seed_seq <<endl;
	//	cout<<seed_scores_LR[i].seed_seq <<endl;

		myfile<<'\t'<<"Left hexamer scores: "<<endl;
	//	cout<<'\t'<<"Left hexamer scores: "<<endl;
		for(int j = 0; j < seed_scores_LR[i].left_hex_site_scores.size(); j++){//output left

			myfile<<'\t'<<seed_scores_LR[i].left_hex_site_scores[j].hexamer<<endl;
	//		cout<<'\t'<<seed_scores_LR[i].left_hex_site_scores[j].hexamer<<endl;
			myfile<<'\t'<<endl;
	//		cout<<'\t'<<endl;

			for (int k = 0; k < seed_scores_LR[i].left_hex_site_scores[j].gene_scores.size(); k++){
				myfile<<'\t'<<'\t'<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].gene_name<<'\t'<<endl;
	//			cout<<'\t'<<'\t'<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].gene_name<<'\t'<<endl;

			//	cout<<endl;
			}//one row of gene names
	//		cout<<endl;

			for (int k = 0; k < seed_scores_LR[i].left_hex_site_scores[j].gene_scores.size(); k++){//for each gene
				myfile<<'\t'<<'\t'<<'\t'<<"gene "<<k+1<<'\t';
	//			cout<<'\t'<<'\t'<<'\t'<<"gene"<<k+1<<'\t';
				for (int l = 0; l <seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores.size();l++){//for each site
					myfile<<'\t'<<'\t'<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores[l].target_substring<<'\t';
	//				cout<<'\t'<<'\t'<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores[l].target_substring<<'\t';	

					myfile<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores[l].pos<<'\t';
	//				cout<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores[l].pos<<'\t';

					myfile<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores[l].score<<'\t';
	//				cout<<seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores[l].score<<'\t';

					if (l==seed_scores_LR[i].left_hex_site_scores[j].gene_scores[k].site_scores.size()){
						myfile<<endl;
						cout<<endl;
					}
			
				}//each row contains all sites in the gene.
				myfile<<endl;
	//			cout<<endl;
			}//for each gene, write a row


		}//output the left score table
	
		myfile<<'\t'<<"Right hexamer scores: "<<endl;
//		cout<<'\t'<<"Right hexamer scores: "<<endl;
		for (int j = 0; j < seed_scores_LR[i].right_hex_site_scores.size(); j++){//output right
		
			myfile<<'\t'<<seed_scores_LR[i].right_hex_site_scores[j].hexamer<<endl;
//			cout<<'\t'<<seed_scores_LR[i].right_hex_site_scores[j].hexamer<<endl;
			myfile<<'\t'<<endl;
//			cout<<'\t'<<endl;

			for (int k = 0; k < seed_scores_LR[i].right_hex_site_scores[j].gene_scores.size(); k++){
				myfile<<'\t'<<'\t'<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].gene_name<<'\t'<<endl;
//				cout<<'\t'<<'\t'<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].gene_name<<'\t'<<endl;

			//	cout<<endl;
			}//one row of gene names
			cout<<endl;

			for (int k = 0; k < seed_scores_LR[i].right_hex_site_scores[j].gene_scores.size(); k++){//for each gene
				myfile<<'\t'<<'\t'<<'\t'<<"gene "<<k+1<<'\t';
				cout<<'\t'<<'\t'<<'\t'<<"gene"<<k+1<<'\t';
				for (int l = 0; l <seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores.size();l++){//for each site
					myfile<<'\t'<<'\t'<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores[l].target_substring<<'\t';
					cout<<'\t'<<'\t'<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores[l].target_substring<<'\t';	

					myfile<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores[l].pos<<'\t';
					cout<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores[l].pos<<'\t';

					myfile<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores[l].score<<'\t';
					cout<<seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores[l].score<<'\t';

					if (l==seed_scores_LR[i].right_hex_site_scores[j].gene_scores[k].site_scores.size()){
						myfile<<endl;
						cout<<endl;
					}
			
				}//each row contains all sites in the gene.
				myfile<<endl;
				cout<<endl;
			}//for each gene


		}//output the right score table

	}//for each seed

	myfile.close();
}

void FileWriter::printOctamerScores(string file_name5, vector<seed_gene_site_score> seedoctamer_scores){
	ofstream myfile;
	myfile.open(file_name5);
	for(vector<seed_site_score>::size_type i = 0; i<seedoctamer_scores.size(); i++){
	
		myfile<<seedoctamer_scores[i].seed_seq<<endl;
//		cout<<seedoctamer_scores[i].seed_seq <<endl;


		for(int j = 0; j < seedoctamer_scores[i].seedgenesite_scores.size(); j++){//output left

			myfile<<'\t'<<seedoctamer_scores[i].seedgenesite_scores[j].hexamer<<endl;
		//	cout<<'\t'<<seedoctamer_scores[i].seedgenesite_scores[j].hexamer<<endl;
			myfile<<'\t'<<endl;
		//	cout<<'\t'<<endl;

			for (int k = 0; k < seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores.size(); k++){
				myfile<<'\t'<<'\t'<<"Gene "<<k<<": "<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].gene_name<<'\t'<<endl;
		//		cout<<'\t'<<'\t'<<"Gene "<<k<<": "<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].gene_name<<'\t'<<endl;

			//	cout<<endl;
			}//one row of gene names
	//		cout<<endl;

			for (int k = 0; k < seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores.size(); k++){//for each gene
				myfile<<'\t'<<'\t'<<'\t'<<"gene "<<k+1<<'\t';
		//		cout<<'\t'<<'\t'<<'\t'<<"gene"<<k+1<<'\t';
				for (int l = 0; l <seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores.size();l++){//for each site
					myfile<<'\t'<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].target_substring<<'\t';
		//			cout<<'\t'<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].target_substring<<'\t';

					myfile<<'\t'<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].target_seq<<'\t';
		//			cout<<'\t'<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].target_seq<<'\t';

					myfile<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].pos<<'\t';
		//			cout<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].pos<<'\t';

					myfile<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].score<<'\t';
		//			cout<<seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores[l].score<<'\t';

					if (l==seedoctamer_scores[i].seedgenesite_scores[j].genesite_scores[k].site_scores.size()){
						myfile<<endl;
		//				cout<<endl;
					}
			
				}//each row contains all sites in the gene.
				myfile<<endl;
	//			cout<<"Seed octamer scores are generated."<<endl;
			}//for each gene, write a row


		}//output the left score table
	


	}//for each seed

	myfile.close();
}

void FileWriter::printSiRNAtargets(string file_name6, vector<si_target_info> siDesigns){

	ofstream myfile;
	myfile.open(file_name6);

	

	for(vector<si_target_info>::size_type i = 0; i < siDesigns.size(); i++){
		myfile<<siDesigns[i].siSeq<<endl;
		
		for (vector<target_info>::size_type j =0; j < siDesigns[i].targets.size(); j++){
			myfile<<'\t'<<siDesigns[i].targets[j].gene_name<<endl;
			myfile<<'\t'<<
				'\t'<<siDesigns[i].targets[j].pos<<
				'\t'<<siDesigns[i].targets[j].target_seq<<
				'\t'<<siDesigns[i].targets[j].score<<
				endl;
		}//for each target of this siRNA

	}//for each siRNA designed

	myfile.close();

}

void FileWriter::saveAlignAll (string outfile_7, vector<siRNA_target_align> align_results){

	ofstream myfile;
	myfile.open(outfile_7);
		for(vector<siRNA_target_align>::size_type i =0; i<align_results.size();i++){

		myfile<<"siRNA ID: "<<align_results[i].siRNA_index<<endl;
		myfile<<"Designed siRNA: " <<align_results[i].siRNA<<endl;
		myfile<<"Target gene name: "<< align_results[i].target_information.gene_name<<endl;
		myfile<<"Target site position:"<<  align_results[i].target_information.pos<<endl;
		myfile<<"Target site sequence: "<<align_results[i].target_information.target_seq<< endl;
	
		
		myfile<<"Alignment score: "<<align_results[i].al_result.match_score<<endl;
		myfile<<"BC-dependent miScore: "<<'\t'<<align_results[i].al_result.miScore<<endl;
		myfile<<"siRNA: "<<'\t'<<'\t'<<align_results[i].al_result.cons_query<<endl;
		myfile<<"       "<<'\t'<<'\t'<<align_results[i].al_result.match_symbols<<endl;
		myfile<<"Target: "<<'\t'<<align_results[i].al_result.cons_subject<<endl;
		myfile<<endl;
	}

	myfile.close();

}

void FileWriter::saveAlignAll_excel_tablimit (string outfile_8, vector<siRNA_target_align> align_results){

	ofstream myfile;
	myfile.open(outfile_8);

	//print title line
	myfile<<
		"siRNA ID"<<'\t'<<
		"siRNA sequence"<<'\t'<<
		"Target gene name"<<'\t'<<
		"Target site position"<<'\t' <<
		"Target site sequence"<<'\t'<<
		"Alignment score"<<'\t'<<
		"miScore is: "<<'\t'<<
		"Aligned siRNA"<<'\t'<<
		"Aligned symbols"<<'\t'<<
		"Aligned target"<<endl;

		for(vector<siRNA_target_align>::size_type i =0; i<align_results.size();i++){
		myfile<<		
			align_results[i].siRNA_index<<'\t'<<
			align_results[i].siRNA<<'\t'<<
			align_results[i].target_information.gene_name<<'\t'<<
			align_results[i].target_information.pos<<'\t'<<
			align_results[i].target_information.target_seq<< '\t'<<		
			align_results[i].al_result.match_score<<'\t'<<
			align_results[i].al_result.miScore<<'\t'<<
			" "<<align_results[i].al_result.cons_query<<'\t'<<
			" "<<align_results[i].al_result.match_symbols<<'\t'<<
			" "<<align_results[i].al_result.cons_subject<<endl;
	}

	myfile.close();

}

void FileWriter::saveHits (string outfile_9, vector<caltarget> sortedHits){
	
	ofstream myfile;
	myfile.open(outfile_9);

	//print title line
	myfile<<"siRNA ID"<<'\t'
		<<"siRNA sequence"
		<<'\t'<<"target counts"
		<<'\t'<<"Total miScore above threshold"
		<<'\t'<<"Average miScore above threshold"
		<<endl;
	cout<<"siRNA ID"<<'\t'
		<<"siRNA sequence"
		<<'\t'<<"target counts"
		<<'\t'<<"Total miScore above threshold"
		<<'\t'<<"Average miScore above threshold"
		<<endl;

	for (int i = 0; i < sortedHits.size(); i++) {
		myfile<<sortedHits[i].siRNA_ID<<'\t'
			<<sortedHits[i].target_counts<<'\t'
			<<sortedHits[i].siRNA_seq<<'\t'
			<<sortedHits[i].total_above_miScore<<'\t'
			<<sortedHits[i].average_above_miScore<<endl;	

		cout<<sortedHits[i].siRNA_ID<<'\t'
			<<sortedHits[i].siRNA_seq<<'\t'
			<<sortedHits[i].target_counts<<'\t'
			<<sortedHits[i].total_above_miScore<<'\t'
			<<sortedHits[i].average_above_miScore<<endl;	

	}//for each entry in sorted hit list



}//wirte sorted hit list