using namespace std;

#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>


#ifndef COMPLEMENTER_H
#define COMPLEMENTER_H
#include "Complementer.h"
#endif

#ifndef REVERSER_H
#define REVERSER_H
#include "Reverser.h"
#endif

#ifndef REVCOMPER_H
#define REVCOMPER_H
#include "Revcomper.h"
#endif

#ifndef ASSEMBLESI_H
#define ASSEMBLESI_H
#include "AssembleSi.h"
#endif

#ifndef SCORER_H
#define SCORER_H
#include "Scorer.h"
#endif

//#include "Reverser.h"
//#include "Complementer.h"
//#include "Revcomper.h"

struct alignment_config{
	string cons_subject; //output constructed subject sequence with gaps 
	string cons_query; //ouput constructed quety sequence with gaps
	string match_symbols; //output matching symbols between the subject and the query of bars or stars or spaces.
	int match_score; //estimate of the binding affinity of the siRNA to the target
	int miScore;
};


struct nonseed_parameters{
/******************
Center part of non-seed scores
******************/
int center_wc_score;
int center_wb_score;
int center_mm_cost;
int query_gap;
int subject_gap;
/*******************
Bulge and tail scoring system
*********************/
int bulgetail_wc;
int bulgetail_wb;
int bulgetail_mm;
int bulgetial_gap;

};


struct seed_parameters{
/*****************
seed region scoring system
********************/
int seed_wc;
int seed_wb;
int seed_mm;
int seed_gap;
};



struct sitarget_align{
string siRNA;

string target_seq;
string target_name;

int start_pos;
int match_score;
int alignment_score;
int BC_score;
};



class Aligner{
public:
//	vector<sitarget_align> aligneAll(vector<sitarget_pair>);
	alignment_config aligne2seq(string target_seq, string siRNA_seq);//caller of the alignment method, it supplies parameters
	
	
	alignment_config cons_align(string target_seq, string siRNA_seq, seed_parameters, nonseed_parameters);
	
	string cons_subject_target(string str1, string str2);

	alignment_config NWalign(string subject, string query, nonseed_parameters); //non-seed part alignment
	vector<vector<int>> fill_matrix(string subject, string query, nonseed_parameters); //fill the scoring matrix
	alignment_config trace_back(vector<vector<int>>, string subject, string query, nonseed_parameters); //trace back to produce the alignment;


	alignment_config NWalign(string subject, string query, seed_parameters); //overloaded for the seed
	vector<vector<int>> fill_matrix(string target_seq, string siRNA_seq, seed_parameters);//Overload function: for seed 
	alignment_config trace_back(vector<vector<int>>, string subject, string query, seed_parameters); //Overload function: for seed 
	
	string extract_query(string siRNAseq);
	string extract_subject(string targetseq);
	string extract_subjectseed(string input_target, int seed_len);


	
};