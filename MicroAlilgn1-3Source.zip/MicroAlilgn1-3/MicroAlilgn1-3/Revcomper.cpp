using namespace std;
#include "Revcomper.h"

string Revcomper::reverse_complement(string query_DNA){
    int siRNA_length = query_DNA.length();
    string complementDNA = ""; 
    string revCompDNA = "";
    	
	//System.out.println(siRNA_length);


    //complementDNA = get_complement(query_DNA);
	Complementer comp;
	complementDNA = comp.get_complement(query_DNA);

	Reverser rev;
    revCompDNA = rev.get_reverse(complementDNA);
	//cout<<"The RevComp of your input is: "<< endl << revCompDNA<<endl; 
    return revCompDNA; 
    }   
