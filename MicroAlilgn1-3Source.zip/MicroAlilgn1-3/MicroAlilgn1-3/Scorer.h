using namespace std;

#include <iostream>
#include <string>
#include <fstream>
#include <algorithm>
#include <vector>
#include <sstream>

class Scorer{

public:

	int total_score;
	double dep_score; //region-interdependent score;

	double get_score(int seedend, int subject_pos, int query_pos, string symbol, string strand_lable);
	//double 
	double score_alignment(string cons_query, string cons_subject, string cons_align_symbols, string target);
	double calculate_dependent_score(	int seedscore,						
										int A_score,
										int A_unpaired,
										int A_symbol_ct,
										int B_score,
										int B_unpaired,
										int B_symbol_ct,
										int C_score,
										int C_unpaired,
										int C_symbol_ct,
										int D_score,
										int D_unpaired,
										int D_symbol_ct
									);
	//double score2percent();//convert the miScore to an efficiency percentage comparing to perfectly matching siRNA

};