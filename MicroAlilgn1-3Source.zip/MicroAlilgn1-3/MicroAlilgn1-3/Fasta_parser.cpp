using namespace std;
#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>

#include "Fasta_parser.h"

//#include "Filelist_maker.h"

vector<fasta_sequence> Fasta_parser::fasta2list(string filename){	
	
	vector<fasta_sequence> geneseq_list;
	
	//stores the current sequence name, then save in the struct fasta_sequence
	string seq_name;

	// a temporary variable that holds the current line read, 
	//will be appended to when next line is read to construct a new sequence.
	string temp_seq;

	//need this to get the sequence name without '>'
	int name_len; 
	string word, stored_seq; 
	fasta_sequence tempseq;

	ifstream infile (filename);
	if (infile.is_open())
	{
		int seq_count = 0; //trace the current sequence being analyzed
		while ( infile.good()){
		getline (infile, word);
		//cout << word << endl;
		if (word.length() > 0){
			if (word[0] == '>') {
				if (seq_count != 0){
				//if this is not the first sequence, store the last sequence
					tempseq.sequence_name = seq_name;
					cout<<"Fasta parser is storing this sequence in a list: "<<seq_name<<endl;

					tempseq.sequence = stored_seq;
					stored_seq = "";
					geneseq_list.push_back(tempseq);
					//the above push back makes sure that new sequences will be added to the existig list.
				}
				seq_count++;
				name_len = word.length()-1;
				seq_name = word.substr(1,name_len);
			}//if first char is '>'
			else {	//this is not a line for the sequence name, this is a line of the actual sequence
				transform(word.begin(), word.end(), word.begin(), toupper);
				stored_seq.append(word); //build a continuous sequence of the FASTA file sequence
				}
			}//if word length > 0
		}//while
	tempseq.sequence_name = seq_name;
	tempseq.sequence = stored_seq;

	geneseq_list.push_back(tempseq);
	//the above push back makes sure that new sequences will be added to the existig list.

	infile.close();
	}//if
	else cout << "Unable to open input file"; 
//	cout<<geneseq_list<<endl;
	return geneseq_list;
}//fasta2list

