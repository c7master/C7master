using namespace std;

#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>

#ifndef COMMONSITEFINDER_H 
#define COMMONSITEFINDER_H
#include "CommonSiteFinder.h"
#endif

#ifndef COMPLEMENTER_H
#define COMPLEMENTER_H
#include "Complementer.h"
#endif

#ifndef REVERSER_H
#define REVERSER_H
#include "Reverser.h"
#endif

#ifndef REVCOMPER_H
#define REVCOMPER_H
#include "Revcomper.h"
#endif

#ifndef SEEDOCTAMER_H
#define SEEDOCTAMER_H
#include "SeedOctamer.h"
#endif

/********** Data structures for the output vector of siRNA and list of the target sites information*****************/
struct target_info{
	string gene_name;
	int pos;
	string target_seq;
	int score;
};

struct si_target_info{
	string siSeq;
	vector<target_info> targets;
};



/*****************************************/

class AssembleSi{
public:
	vector<si_target_info> assembleSiRNA (vector<seed_bulge_tail> seedtargetinfo);

	string cons_siRNA(string seed, string bulge, string center, string tail);

};

