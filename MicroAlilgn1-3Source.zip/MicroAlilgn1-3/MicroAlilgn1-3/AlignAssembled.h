using namespace std;

#include <string>
#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <sstream>
#include <algorithm>


#ifndef COMPLEMENTER_H
#define COMPLEMENTER_H
#include "Complementer.h"
#endif

#ifndef REVERSER_H
#define REVERSER_H
#include "Reverser.h"
#endif

#ifndef REVCOMPER_H
#define REVCOMPER_H
#include "Revcomper.h"
#endif

#ifndef ASSEMBLESI_H
#define ASSEMBLESI_H
#include "AssembleSi.h"
#endif

#ifndef ALIGNER_H
#define ALIGNER_H
#include "Aligner.h"
#endif
/************************************
class methods design:
1. Take the vector of siRNA/target struct from AssembleSi's output, make an enumertated list of 
siRNAs and their targets along with all information stored. A new 2D vector is make with a new struct. 
This new vector contains redundancies. 
2. Use this vector of siRNA/target pairs as input, feed into prep method to extract the sequence 
information only. Store the extracted sequence pairs in a new vector.
3. Feed this vector into the Aligner class method to product the alignment. The returned result will be
combined in the caller method to produce a complete list of siRNA/target information, alignment, and scores.
Write the result to a file.
4. Return this list for a selection method in the output class.

*************************************/





	
struct siRNA_target_align{//output of the method
	string siRNA;
	int siRNA_index; //unique original index in the siRNA_target_info table
	target_info target_information; //defined in Assembler
	alignment_config al_result;//defined in Aligner
	int BC_score;
};

struct sitargetinfo_pair{
//enumerate all pairs in the si_target_info table
	string siRNA;
	int siRNA_index;
	target_info target_info;

};

struct sitarget_pair{
	//extracted sequence information only from the struct si-target-info_pair struct
	//the vector of this struct is fed into the alignment method
	string siRNA;
	int siRNA_index;
	string target_seq;
};

class AlignAssembled {
public:
	vector<sitargetinfo_pair> enumerate_info(vector<si_target_info>); 
		//convert the list into a enumerated vector, prepare it for the alignment method.
	vector<sitarget_pair> extract_pairs(vector<sitargetinfo_pair>);

	vector<siRNA_target_align> aligneAll(vector<si_target_info>);
	//This is the master caller of the alignment method;


};