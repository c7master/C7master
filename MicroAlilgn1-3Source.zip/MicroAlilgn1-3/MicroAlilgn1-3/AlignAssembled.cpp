#include "AlignAssembled.h"

vector<siRNA_target_align> AlignAssembled::aligneAll(vector<si_target_info> siRNA_targetinfo_table){
	//this method takes a vector of siRNA and target site pairs, along with target site information,
	//and produces alignment for each pair of the siRNA and the target. The alignment is performed by
	//calling Aligner class methods
	
	//declare output
	vector<siRNA_target_align> siRNA_targeting_align_table;
	siRNA_target_align curr_align_info;

	//prepare input
	vector<sitargetinfo_pair> enumerate_sitar_info = enumerate_info(siRNA_targetinfo_table);
	vector<sitarget_pair> sitar_pairs = extract_pairs(enumerate_sitar_info);

	Aligner ali;

	//now construct the output
	for (vector<sitargetinfo_pair>::size_type i = 0; i < enumerate_sitar_info.size(); i++){
		curr_align_info.siRNA = enumerate_sitar_info[i].siRNA;
		curr_align_info.siRNA_index = enumerate_sitar_info[i].siRNA_index;
		curr_align_info.target_information = enumerate_sitar_info[i].target_info;

		curr_align_info.al_result = ali.aligne2seq(sitar_pairs[i].target_seq, sitar_pairs[i].siRNA);

		siRNA_targeting_align_table.push_back(curr_align_info);
	
	}


	//print output

	for(vector<siRNA_target_align>::size_type i =0; i<siRNA_targeting_align_table.size();i++){
		
		cout<<"siRNA ID: "<<siRNA_targeting_align_table[i].siRNA_index<<endl;
		cout<<"Designed siRNA: " <<siRNA_targeting_align_table[i].siRNA<<endl;
		cout<<"Target site sequence: "<<siRNA_targeting_align_table[i].target_information.target_seq<< endl;
		cout<<"Target gene name: "<< siRNA_targeting_align_table[i].target_information.gene_name <<endl;
		cout<<"Target site position: "<< siRNA_targeting_align_table[i].target_information.pos <<endl;
		cout<<"Alignment score: "<<siRNA_targeting_align_table[i].al_result.match_score<<endl;
		cout<<'\t'<<siRNA_targeting_align_table[i].al_result.cons_query<<'\t'<<"siRNA"<<endl;
		cout<<'\t'<<siRNA_targeting_align_table[i].al_result.match_symbols<<endl;
		cout<<'\t'<<siRNA_targeting_align_table[i].al_result.cons_subject<<'\t'<<"Target"<<endl;
		cout<<endl;
	}


	return siRNA_targeting_align_table;
}

vector<sitargetinfo_pair> AlignAssembled::enumerate_info(vector<si_target_info> all_sitars){
//convert the list into a enumerated vector, prepare it for the alignment method.

	//declare output
	vector<sitargetinfo_pair> enu_sitar_infotable;
	sitargetinfo_pair current_sitar_pair;

	for (vector<si_target_info>::size_type i = 0; i < all_sitars.size();i++){
		current_sitar_pair.siRNA = all_sitars[i].siSeq;
		current_sitar_pair.siRNA_index  = i+1;
		target_info curr_target;

		for (vector<target_info>::size_type j = 0; j < all_sitars[i].targets.size();j++){
		
			current_sitar_pair.target_info =  all_sitars[i].targets[j];

			enu_sitar_infotable.push_back(current_sitar_pair);
		}//for j
	
	}//for i

	return enu_sitar_infotable;

} 

vector<sitarget_pair> AlignAssembled::extract_pairs(vector<sitargetinfo_pair> enu_sitars_info){
	//declare output
	vector<sitarget_pair> sitars;
	sitarget_pair curr_sitar;

	for (vector<sitargetinfo_pair>::size_type i = 0; i< enu_sitars_info.size(); i++){
		curr_sitar.siRNA = enu_sitars_info[i].siRNA;
		curr_sitar.siRNA_index = enu_sitars_info[i].siRNA_index;
		curr_sitar.target_seq = enu_sitars_info[i].target_info.target_seq;
		sitars.push_back(curr_sitar);
	}//for all entries in enumerated siRNA/target information table

	return sitars;

}

