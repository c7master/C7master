



/*********************************************************************
SeqPro's Aligner code
*********************************************************************/
#include "Aligner.h"
using namespace std;


alignment_config Aligner::aligne2seq(string subject_seq, string query_seq){//caller of the alignment method, it supplies parameters
	//define output
	//declare output
	alignment_config alignment_result;

	//prepare input
	//The query and subject are not processed here yet, they are the original siRNA and complete target site sequences. 

	//define alignment parameters
	seed_parameters spar;
	spar.seed_wc = 3;
	spar.seed_wb = 0;
	spar.seed_mm = -1;
	spar.seed_gap = -2;

	nonseed_parameters body_parameters;
	body_parameters.center_wc_score = 4;
	body_parameters.center_wb_score = 2;

	body_parameters.center_mm_cost = -1; //-2;
		//-6;
	body_parameters.query_gap = -3; //-4;
	body_parameters.subject_gap = -3; //-2;

	body_parameters.bulgetail_wc = 2;
	body_parameters.bulgetail_wb = 1;
	body_parameters.bulgetail_mm = 0;
	body_parameters.bulgetial_gap = -2;

	//non-seed perfect match for siRNA is 34 total
	//>=27 are effective hits; <20 are ineffective. Use >=20 as cutoff. 

	int seedlen = 8;

	string subject_nonseed = extract_subject(subject_seq);
	string subject_seed = extract_subjectseed(subject_seq, seedlen);
	string total_subject = cons_subject_target(subject_nonseed, subject_seed);//constructed in 3' ->5' direction, only nt, no symbols

	alignment_result = cons_align(subject_seq, query_seq, spar, body_parameters);

	//evaluate the miRNA binding profile score
	Scorer sco;
	alignment_result.miScore = sco.score_alignment(alignment_result.cons_query, alignment_result.cons_subject, alignment_result.match_symbols, total_subject);

	return alignment_result;

}


alignment_config Aligner::cons_align(string target_seq, string siRNA_seq, seed_parameters seedpar, nonseed_parameters bodypar){


	alignment_config seed_alignment, nonseed_alignment, total_alignment;
	int seed_len =8;

	/**********construct the alignment in the non-seed part*****************/
	//extract the non-seed region of the siRNA sequence, and reverse it for alignment. This is the query.
	string query_nonseed = extract_query(siRNA_seq);//this method 

	//string query = get_reverse(siRNA_seq); //reverse the siRNA input for complementarity analysis
	int queryCount = query_nonseed.length() + 1;

	//extract the non-seed region fo the target sequence, keep it as it is. This is the subject.
	string subject_nonseed = extract_subject(target_seq);

	//string subject = target_seq;
	int subjectCount = subject_nonseed.length() + 1;

	nonseed_alignment = NWalign(subject_nonseed, query_nonseed, bodypar);//calling with the non-seed part only

	/****
	cout<<"Non-seed alignment: "<<endl;
	cout<<nonseed_alignment.cons_query<<endl;
	cout<<nonseed_alignment.match_symbols<<endl;
	cout<<nonseed_alignment.cons_subject<<endl;
	cout<<nonseed_alignment.match_score<<endl;
	****/


	

	/***************construct the seed alignment************************************/
	Reverser re;
	string query_seed = re.get_reverse(siRNA_seq.substr(0,seed_len));//seed of siRNA, in reverse direction for the alignment

	string subject_seed = extract_subjectseed(target_seq, seed_len);
	

	seed_alignment = NWalign(subject_seed, query_seed, seedpar);

	/****
	cout<<"Seed alignment: "<<endl;
	cout<<seed_alignment.cons_query<<endl;
	cout<<seed_alignment.match_symbols<<endl;
	cout<<seed_alignment.cons_subject<<endl;
	cout<<seed_alignment.match_score<<endl;
	****/

	/****************construct the total alignment output***********************************/
	total_alignment.cons_query =  nonseed_alignment.cons_query+seed_alignment.cons_query;
	total_alignment.cons_subject = nonseed_alignment.cons_subject+seed_alignment.cons_subject;
	total_alignment.match_symbols = nonseed_alignment.match_symbols + seed_alignment.match_symbols;
	total_alignment.match_score = nonseed_alignment.match_score; //+ seed_alignment.match_score; //use only the non-seed part score for ranking

	return total_alignment;

}


string Aligner::cons_subject_target(string str1, string str2){//construct the seed + nonseed to get the subject used for alignment
	string entire_subject = str1 + str2;
	return entire_subject;
}


alignment_config Aligner::NWalign(string subject, string query, nonseed_parameters bodypar){//for non-seed pairing alignment

	alignment_config output_config, seed_align, total_align;

	vector <vector<int>> scores = fill_matrix(subject, query, bodypar);

	output_config = trace_back(scores, subject, query, bodypar);

	return output_config;

}

vector<vector<int>> Aligner::fill_matrix(string target_seq, string siRNA_seq, nonseed_parameters bodypar){

	//alternative scoring matrix by 2D vectors of int
	vector<vector <int>> scores;

	//extract the non-seed region of the siRNA sequence, and reverse it for alignment. This is the query.
//	string query = extract_query(siRNA_seq);

	string query = siRNA_seq;
	int queryCount = query.length() + 1;

	//calculate the indeces for the center part (BC region) in the non-seed target sequence
	int seedlength = 8;
	int bulge_len = 4;
	int BC_len = 4;
	int tail_len = 5;
	int target_nonseed_len = target_seq.length(); //for 27 nt total target site, this should be 19 nt.

	int BCstart_pos = target_nonseed_len - bulge_len - BC_len;
	int BCend_pos = target_nonseed_len - bulge_len+1;

//	cout<<"BC starts at: "<<BCstart_pos<<endl;
//	cout<<"BC ends at: "<<BCend_pos<<endl;

	string subject = target_seq;
	int subjectCount = subject.length() + 1;

	//extract scoring paramters
	int center_wc = bodypar.center_wc_score;
	int center_wb = bodypar.center_wb_score;
	int center_mm_cost = bodypar.center_mm_cost;					
	int query_gap = bodypar.query_gap;
	int subject_gap = bodypar.subject_gap;	

	int bt_wc = bodypar.bulgetail_wc;
	int bt_wb = bodypar.bulgetail_wb;
	int bt_mm = bodypar.bulgetail_mm;
	int bt_gap = bodypar.bulgetial_gap;



	//initialize the vector matrix
	for (int i = 0; i<queryCount; i++){		
		vector<int> current_row;
		for (int j = 0; j < subjectCount; j++){
			current_row.push_back(0);
		}//for j
		scores.push_back(current_row);
	}//for i

	Complementer co;
	//Filling the vector matrix, from 5' to 3' in siRNA
//	for (int i = 1; i< queryCount; i++){
	for (int i = queryCount-2; i>=0 ; i--){
	
	//	for (int j = 1; j < subjectCount; j++){
		for (int j = subjectCount-2; j >=0 ; j--){
			
			int scroeDiag = 0;

		//	if (j > BCstart_pos+1 && j < BCend_pos+2){//if either region is in the BC region
				//The limits are (BCstart+1, BCend+2), while entering and while leaving the BC region, BC scoring is used.
			if (j > BCstart_pos-2 && j < BCend_pos-1){//if either region is in the BC region
				//The limits are start -2 and end-1 if going from right bottom to top left, entrance-1 and exit -2.

			//	if ( isWatsonCrick(subject.substr(j - 1, 1), query.substr(i - 1, 1)) == 1 ){ //and if wc pair
				if ( co.isWatsonCrick(subject.substr(j , 1), query.substr(i, 1)) == 1 ){ //and if wc pair

				//	scroeDiag = scores[i - 1][ j - 1] + center_wc;	
					scroeDiag = scores[i+1][ j+1] + center_wc;	
				}//if W-C
			//	else if ( isWobbleComp(subject.substr(j - 1, 1), query.substr(i - 1, 1)) == 1 ){ //if wobble pair
				else if ( co.isWobbleComp(subject.substr(j, 1), query.substr(i, 1)) == 1 ){ //if wobble pair

				//	scroeDiag = scores[i - 1][ j - 1] + center_wb;	
					scroeDiag = scores[i+1][ j+1] + center_wb;	
				}//else, it is just G:U pairing by Wobble
				else //else, it is a mismatch

				//	scroeDiag = scores[i - 1][ j - 1] + center_mm_cost;		
				scroeDiag = scores[i+1][ j+1] + center_mm_cost;		

		//		int scroeLeft = scores[i][ j - 1] + query_gap;					
		//		int scroeUp = scores[i - 1][ j] + subject_gap;	

				int scroeLeft = scores[i][ j + 1] + query_gap;					
				int scroeUp = scores[i + 1][ j] + subject_gap;

				int maximumScore = max(max(scroeDiag, scroeLeft), scroeUp);

				scores[i][j] = maximumScore;
			} //if either sequence is in the BC region

			/***********/
			/*************************************************************************/
			else {//in the bulge or tail
			//	if ( isWatsonCrick(subject.substr(j - 1, 1), query.substr(i - 1, 1)) == 1 ){ //if wobble pair
			//		scroeDiag = scores[i - 1][ j - 1] + bt_wc;	
				if ( co.isWatsonCrick(subject.substr(j, 1), query.substr(i, 1)) == 1 ){ //if wobble pair
					scroeDiag = scores[i + 1][ j + 1] + bt_wc;	


					}//all pairings score as +2
		//		else if ( isWobbleComp(subject.substr(j - 1, 1), query.substr(i - 1, 1)) == 1 ){ //if wobble pair
		//			scroeDiag = scores[i - 1][ j - 1] + bt_wb;
				else if ( co.isWobbleComp(subject.substr(j, 1), query.substr(i, 1)) == 1 ){ //if wobble pair
					scroeDiag = scores[i + 1][ j + 1] + bt_wb;	

					}//all pairings score as +2
				else //else, it is a mismatch
				//	scroeDiag = scores[i - 1][ j - 1] + bt_mm;					// mismatch cost is 0

					scroeDiag = scores[i + 1][ j + 1] + bt_mm;

			//	int scroeLeft = scores[i][ j - 1] + bt_gap;					//gap does not cost
				int scroeLeft = scores[i][ j + 1] + bt_gap;	

			//	int scroeUp = scores[i - 1][ j] + bt_gap;
				int scroeUp = scores[i + 1][ j] + bt_gap;

				int maximumScore = max(max(scroeDiag, scroeLeft), scroeUp);

				scores[i][j] = maximumScore;		
			
			}//else in the bulge or tail
			/****************/
			/**************************************************************************/
		}//for j
	
	}//for i

	//Display the vector matrix
	/****
	cout<<"     ";
	for (int j = 0; j < subject.size();j++){
		cout<<subject[j]<<"  ";
	}
	cout<<endl;

	for (int i = 0; i< queryCount; i++){
		if (i==0){	
		cout<<" ";
		}
		for(int j = 0; j < subjectCount; j++){
		
			if (scores[i][j]>=0 && scores[i][j]<10){
				cout<<" ";
			}
			cout<< scores[i][j]<<" ";
		}//j
		cout<<endl;
		cout<<query[i];
	}//i
	****/

	/****

	//write to file
	ofstream myfile;
	myfile.open(outputfile2);
	myfile<<"     ";
	for (int j = 0; j < subject.size();j++){
		myfile<<subject[j]<<"  ";
	}
	myfile<<endl;

	for (int i = 0; i< queryCount; i++){
		if (i == 0){	
			myfile<<" ";
		}
		for(int j = 0; j < subjectCount; j++){
		
			if (scores[i][j]>=0 && scores[i][j]<10){
				myfile<<" ";
			}
			myfile<<scores[i][j]<<" ";
		}//j
		myfile<<endl;
		myfile<<query[i];
	}//i

	myfile.close();
	****/
/**************************************************************************/

	return scores;
}//fill matrix non-seed

alignment_config Aligner::trace_back(vector<vector<int>> scores, string target_seq, string siRNA_seq, nonseed_parameters bodypar){
	//define output
	alignment_config alignment;
	string aligned_subject;	//AlignmentA
	string aligned_query;	//AlignmentB
	string aligned_symbols; //symbols of alignment


	//prepare input
	string query = siRNA_seq;
	int queryCount = query.length() + 1;

	string subject = target_seq;
	int subjectCount = subject.length() + 1;
	
//	int m = queryCount -1;
//	int n = subjectCount -1;

	int m = 0;
	int n = 0;

	//calculate the indeces for the center part (BC region) in the non-seed target sequence
	int seedlength = 8;
	int bulge_len = 4;
	int BC_len = 4;
	int tail_len = 5;
	int target_nonseed_len = target_seq.length(); //for 27 nt total target site, this should be 19 nt.

	int BCstart_pos = target_nonseed_len - bulge_len - BC_len;
	int BCend_pos = target_nonseed_len - bulge_len+1;

	/******************************************
	cout<<"BC starts at: "<<BCstart_pos<<endl;
	cout<<"BC ends at: "<<BCend_pos<<endl;
	/*******************************************/
/**************************************************************************/
	//extract parameters
	int center_wc = bodypar.center_wc_score;
	int center_wb = bodypar.center_wb_score;
	int center_mm_cost = bodypar.center_mm_cost;					
	int query_gap = bodypar.query_gap;
	int subject_gap = bodypar.subject_gap;	

	int bt_wc = bodypar.bulgetail_wc;
	int bt_wb = bodypar.bulgetail_wb;
	int bt_mm = bodypar.bulgetail_mm;
	int bt_gap = bodypar.bulgetial_gap;

	Complementer co;

//	while (m > 0 || n > 0){
	while (m < queryCount-1 || n < subjectCount -1){	
		int scroeDiag = 0;
	//	int query_gap = 0; //open a gap in query (siRNA)
	//	int subject_gap = 0;//open a gap in subject(target mRNA)

		//build the alignment output for both the query and the subject.
		//add 1 nt at a time to the beginning of the output string

	//	if (m == 0 && n > 0){//if query sequence is finished but not the subject 
		if (m == queryCount-1 && n<subjectCount-1){//if query sequence is finished but not the subject 

		//	aligned_subject = subject[n-1] + aligned_subject;	//add 1 nt to the beginning of the alignment output of the subject
		//	aligned_query = "-" + aligned_query;				//add a gap to the beginnning of  alignment output of the query
		//	aligned_symbols =" " + aligned_symbols;
		//	n = n-1;

			aligned_subject = aligned_subject + subject[n];	//add 1 nt to the beginning of the alignment output of the subject
			aligned_query =  aligned_query + "-";				//add a gap to the beginnning of  alignment output of the query
			aligned_symbols = aligned_symbols + " " ;
			n ++;


		}//if

	//	else if (n == 0 && m > 0){//if the subject sequence is ended but not the query sequence
		else if (n == subjectCount -1 && m < queryCount -1){//if the subject sequence is ended but not the query sequence

			/***
			aligned_subject = "-" + aligned_subject;	//add a gap in the alignment output of the subject
			aligned_query = query[m-1] + aligned_query; //add 1 nt in the alignment output of the query
			aligned_symbols =" "+ aligned_symbols;
			m--;

			***/
/**************************************************************************/
			aligned_subject =  aligned_subject+ "-";	//add a gap in the alignment output of the subject
			aligned_query = aligned_query + query[m]; //add 1 nt in the alignment output of the query
			aligned_symbols = aligned_symbols + " ";
			m++;
		}//else if
		
		else {//otherwise, going through the scoring matrix to construct the alignment
			
		//	if (n > BCstart_pos+1 && n<BCend_pos+2 ){//if in the BC-region
				if (n > BCstart_pos-2 && n<BCend_pos-1 ){//if in the BC-region

				/***************This code is to find which type of diagnal movement it is: match or mismatch************/
				/************************************************************************************************
				THIS STEP IS VERY IMPORTANT!!!!! AVOID MIS-ALIGNING BY SIMILAR SCORES!
				************************************************************

				if (isWatsonCrick(query.substr(m-1, 1), subject.substr(n-1, 1)) == 1){ //and if they are W-C pairing
						scroeDiag = center_wc;//W-C match
				}
				else if (isWobbleComp(query.substr(m-1,1), subject.substr(n-1, 1))==1){ //if 2 bases are wobble pairing
					scroeDiag = center_wb; //wobble G:U pairing
					}
				else 
					scroeDiag = center_mm_cost; //mismatch
				/*****************************************************************************/
	/**************************************************************************/

		//		if ((m > 0 && n > 0 && (scores[m][n] == scores[m-1][n-1] + center_wc))&&
		//		(isWatsonCrick(query.substr(m-1, 1), subject.substr(n-1, 1)) == 1)){//W-C match, highest award, +4
			
				if (
					( m<queryCount-1 && n<subjectCount-1 
					&& (scores[m][n] == scores[m+1][n+1] + center_wc)) &&
					(co.isWatsonCrick(query.substr(m, 1), subject.substr(n, 1)) == 1)
				){//W-C match, highest award, +4

					/****
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = "|" + aligned_symbols;
					m--;
					n--;
					****/
	/**************************************************************************/
					aligned_subject =  aligned_subject +subject[n];
					aligned_query =  aligned_query + query[m];
					aligned_symbols =  aligned_symbols + "|";
					m++;
					n++;

				}//move up in query and move left in subject

			//	else if ((m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + center_wb) &&
			//	(isWobbleComp(query.substr(m-1,1), subject.substr(n-1, 1))==1)){//Wobble match, +2
				else if ((m  < queryCount-1 && n < subjectCount-1 && scores[m][n] == scores[m+1][n+1] + center_wb) &&
				(co.isWobbleComp(query.substr(m,1), subject.substr(n, 1))==1)){//Wobble match, +2

					/****
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = "*" + aligned_symbols;
					m--;
					n--;
					***/
					/**************************************************************************/
					aligned_subject = aligned_subject + subject[n];
					aligned_query = aligned_query + query[m];
					aligned_symbols = aligned_symbols + "*";
					m++;
					n++;

				}//move up in query and move left in subject
	
				/*****
				else if (m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + center_mm_cost){//mismatch in BC, severe penalty -8
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = " " + aligned_symbols;
					m--;
					n--;
				}
				*****/
			/**************************************************************************/
				else if (m  < queryCount-1 && n < subjectCount-1 && scores[m][n] == scores[m+1][n+1] + center_mm_cost){//mismatch in BC, severe penalty -8
					aligned_subject =  aligned_subject + subject[n];
					aligned_query = aligned_query + query[m];
					aligned_symbols = aligned_symbols + " " ;
					m++;
					n++;
				}

				/******
				else if (n > 0 && scores[m][n] == scores[m][n-1] + query_gap){ //create a gap in query
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = "-" + aligned_query;
					aligned_symbols  = " "+ aligned_symbols;
					n--;			
				}//gap in query, move left in subject
				*****/
/**************************************************************************/
				else if (n < subjectCount-1 && scores[m][n] == scores[m][n+1] + query_gap){ //create a gap in query
					aligned_subject = aligned_subject + subject[n];
					aligned_query =  aligned_query + "-";
					aligned_symbols  = aligned_symbols + " ";
					n++;			
				}//gap in query, move left in subject

				/******
				else if (m > 0 && scores[m][n] == scores[m-1][n] + subject_gap){//create a gap in subject
					aligned_subject = "-" + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols  = " "+ aligned_symbols;
					m--;
				}//move up in query, gap in subject
				******/
				/**************************************************************************/
				else if (m  < queryCount-1 && scores[m][n] == scores[m+1][n] + subject_gap){//create a gap in subject
					aligned_subject = aligned_subject + "-";
					aligned_query =  aligned_query + query[m];
					aligned_symbols  = aligned_symbols + " ";
					m++;
				}//move up in query, gap in subject

		
			}//if in the BC region

			else { //going through the bulge or tail
		

				/**************To find out what kind of diagnal movement it is****************
				if (isWobbleComp(query.substr(m-1,1), subject.substr(n-1, 1)) == 1){ //if 2 bases are wobble pairing

					if (isWatsonCrick(query.substr(m-1, 1), subject.substr(n-1, 1)) == 1){ //and if they are W-C pairing

						scroeDiag = bt_wc;//W-C match
					}
					else { //just a wobble pairing

						scroeDiag = bt_wb; //wobble G:U pairing
					}
				}//if paired
				else 
					scroeDiag = bt_mm; //mismatch
					/************************************************************************/


				/*****
				if ((m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + bt_wc)&& 
					(isWatsonCrick(query.substr(m-1, 1), subject.substr(n-1, 1)) == 1)){//W-C match, +2

					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = "|" + aligned_symbols;
					m--;
					n--;
				}//move up in query and move left in subject
				*****/
				 /**************************************************************************/
				if ((m<queryCount-1 && n<subjectCount-1 && scores[m][n] == scores[m+1][n+1] + bt_wc)&& 
					(co.isWatsonCrick(query.substr(m, 1), subject.substr(n, 1)) == 1)){//W-C match, +2

					aligned_subject =  aligned_subject + subject[n];
					aligned_query = aligned_query + query[m];
					aligned_symbols = aligned_symbols +"|";
					m++;
					n++;
				}//move up in query and move left in subject



				/*****
				else if ((m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + bt_wb) &&
				(isWobbleComp(query.substr(m-1,1), subject.substr(n-1, 1)) == 1)){//Wobble match +2
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = "*" + aligned_symbols;
					m--;
					n--;
				}//move up in query and move left in subject
				*****/
				/**************************************************************************/
				else if ((m<queryCount-1 && n<subjectCount-1 && scores[m][n] == scores[m+1][n+1] + bt_wb) &&
				(co.isWobbleComp(query.substr(m,1), subject.substr(n, 1)) == 1)){//Wobble match +2
					aligned_subject = aligned_subject+subject[n];
					aligned_query = aligned_query + query[m];
					aligned_symbols =  aligned_symbols + "*";
					m++;
					n++;
				}//move up in query and move left in subject


				/*****
				else if (m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + bt_mm){//mismatch, no cost
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = " " + aligned_symbols;
					m--;
					n--;
				}
				*****/
				/**************************************************************************/
				else if (m<queryCount-1 && n<subjectCount-1 && scores[m][n] == scores[m+1][n+1] + bt_mm){//mismatch, no cost
					aligned_subject = aligned_subject +subject[n]  ;
					aligned_query = aligned_query + query[m]  ;
					aligned_symbols = aligned_symbols + " " ;
					m++;
					n++;
				}




				/****************
				else if (n > 0 && scores[m][n] == scores[m][n-1] + bt_gap){ //create a gap in query
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = "-" + aligned_query;
					aligned_symbols  = " "+ aligned_symbols;
					n--;			
				}//gap in query, move left in subject
				*********/
				/**************************************************************************/
				else if (n<subjectCount-1  && scores[m][n] == scores[m][n+1] + bt_gap){ //create a gap in query
					aligned_subject =  aligned_subject + subject[n];
					aligned_query = aligned_query + "-" ;
					aligned_symbols  = aligned_symbols  + " ";
					n++;			
				}//gap in query, move left in subject


				/****
				else if (m > 0 && scores[m][n] == scores[m-1][n] + bt_gap){//create a gap in subject
					aligned_subject = "-" + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols  = " "+ aligned_symbols;
					m--;
				}//move up in query, gap in subject
				*******/
				/**************************************************************************/
				else if (m<queryCount-1 && scores[m][n] == scores[m+1][n] + bt_gap){//create a gap in subject
					aligned_subject = aligned_subject + "-";
					aligned_query = aligned_query + query[m];
					aligned_symbols = aligned_symbols + " ";
					m++;
				}//move up in query, gap in subject



			}//else in the bulge or tail

		}//else neither sequence is at the end

	}//while


	alignment.cons_query = aligned_query;
	alignment.cons_subject = aligned_subject;
	alignment.match_symbols = aligned_symbols;
//	alignment.match_score = scores[queryCount-1][subjectCount-1]; 
	alignment.match_score = scores[0][0]; 
	//take the last filled score as the overall score for the alignment

	return alignment;

}


alignment_config Aligner::NWalign(string subject, string query, seed_parameters spar){//for seed pairing alignment

	alignment_config output_config;

	vector <vector<int>> scores = fill_matrix(subject, query, spar);

	output_config = trace_back(scores, subject, query, spar);

	return output_config;

}

vector<vector<int>> Aligner::fill_matrix(string target_seq, string siRNA_seq, seed_parameters spar){

	vector<vector <int>> scores;

	string query = siRNA_seq;
	int queryCount = query.length() + 1;

	string subject = target_seq;
	int subjectCount = subject.length() + 1;

	int wc = spar.seed_wc;
	int wb = spar.seed_wb;
	int mm = spar.seed_mm;
	int gap = spar.seed_gap;

	Complementer co2;
	//initialize the vector matrix
	for (int i = 0; i<queryCount; i++){		
		vector<int> current_row;
		for (int j = 0; j < subjectCount; j++){
			current_row.push_back(0);
		}//for j
		scores.push_back(current_row);
	}//for i



	//Filling the vector matrix
	for (int i = 1; i< queryCount; i++){
	
		for (int j = 1; j < subjectCount; j++){
			
			int scroeDiag = 0;			

			if ( co2.isWatsonCrick(subject.substr(j - 1, 1), query.substr(i - 1, 1)) == 1 ){ //and if wc pair

					scroeDiag = scores[i - 1][ j - 1] + wc;	
			}//if W-C
			else if ( co2.isWobbleComp(subject.substr(j - 1, 1), query.substr(i - 1, 1)) == 1 ){ //if wobble pair{
				scroeDiag = scores[i - 1][ j - 1] + wb;	
			}//else, it is just G:U pairing by Wobble

			else {//else, it is a mismatch
				scroeDiag = scores[i - 1][ j - 1] + mm;	
			}				// mismatch cost is 0

			int scroeLeft = scores[i][ j - 1] + gap;					//gap does not cost, but gain +1
			int scroeUp = scores[i - 1][ j] + gap;

			int maximumScore = max(max(scroeDiag, scroeLeft), scroeUp);

			scores[i][j] = maximumScore;		

			}//for j
	
		}//for i

	/****
	//Display the vector matrix
	for (int i = 0; i< queryCount; i++){
		
		for(int j = 0; j < subjectCount; j++){
			if (scores[i][j]>=0){
				cout<<" ";
			}
			cout<< scores[i][j];
		}
		cout<<endl;
	}
	******/
	/**************************************************************************/
	return scores;
}//fill matrix

alignment_config Aligner::trace_back(vector<vector<int>> scores, string target_seq, string siRNA_seq, seed_parameters spar){

	//define output
	alignment_config alignment;
	string aligned_subject;	//AlignmentA
	string aligned_query;	//AlignmentB
	string aligned_symbols; //alginment symbols

	//prepare input
	string query = siRNA_seq;
	int queryCount = query.length() + 1;

	string subject = target_seq;
	int subjectCount = subject.length() + 1;
	
	//extract paramters for seed
	int wc = spar.seed_wc;
	int wb = spar.seed_wb;
	int mm = spar.seed_mm;
	int gap = spar.seed_gap;

	int m = queryCount -1;
	int n = subjectCount -1;

//	cout<<"seed m: "<<m<<endl;
//	cout<<"seed n: "<< n <<endl;

	while (m > 0 || n > 0){
		
		int scroeDiag = 0;

		//build the alignment output for both the query and the subject.
		//add 1 nt at a time to the beginning of the output string
		if (m == 0 && n > 0){//if query sequence is finished but not the subject 

			aligned_subject = subject[n-1] + aligned_subject;	//add 1 nt in the alignment output of the subject
			aligned_query = "-" + aligned_query;				//add a gap to the alignment output of the query
			aligned_symbols =" " + aligned_symbols;
			
			n = n-1;
		}//if

		else if (n == 0 && m > 0){//if the subject sequence is ended but not the query sequence
		
			aligned_subject = "-" + aligned_subject;	//add a gap in the alignment output of the subject
			aligned_query = query[m-1] + aligned_query; //add 1 nt in the alignment output of the query
			aligned_symbols =" "+ aligned_symbols;
			m--;
		}//else if
		
		else {//otherwise, going through the scoring matrix to construct the alignment


			/********************************************************************
			

					if (isWatsonCrick(query.substr(m-1, 1), subject.substr(n-1, 1)) == 1){ //and if they are W-C pairing
	
						scroeDiag = wc;//W-C match
					}
					else 	if (isWobbleComp(query.substr(m-1,1), subject.substr(n-1, 1))==1){ //if 2 bases are wobble pairing{ //just a wobble pairing

						scroeDiag = wb; //wobble G:U pairing
					}
		
					else 
					scroeDiag = mm; //mismatch
				/*******************************************************/
		/**************************************************************************/
				if (m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + wc){//W-C match, highest award, +2

					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = "|" + aligned_symbols;
					m--;
					n--;
				}//move up in query and move left in subject

				else if (m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + wb){//Wobble match, 0
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = "*" + aligned_symbols;
					m--;
					n--;
				}//move up in query and move left in subject
	
				else if (m > 0 && n > 0 && scores[m][n] == scores[m-1][n-1] + mm){//mismatch in BC, severe penalty 0
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols = " " + aligned_symbols;
					m--;
					n--;
				}

				else if (n > 0 && scores[m][n] == scores[m][n-1] + gap){ //create a gap in query
					aligned_subject = subject[n-1] + aligned_subject;
					aligned_query = "-" + aligned_query;
					aligned_symbols  = " "+ aligned_symbols;
					n--;			
				}//gap in query, move left in subject

				else if (m > 0 && scores[m][n] == scores[m-1][n] + gap){//create a gap in subject
					aligned_subject = "-" + aligned_subject;
					aligned_query = query[m-1] + aligned_query;
					aligned_symbols  = " "+ aligned_symbols;
					m--;
				}//move up in query, gap in subject	
	
		}//else neither sequence is at the end

	}//while


	alignment.cons_query = aligned_query;
	alignment.cons_subject = aligned_subject;
	alignment.match_symbols = aligned_symbols;
	alignment.match_score = scores[queryCount-1][subjectCount-1];

	return alignment;

}//overloaded traceback for seed alignment


/*******/
			/**************************************************************************/
string Aligner::extract_query(string input_alignseq){
	string output_alignseq;

	int seed_len = 8;

	Reverser rev; //declare an object from the reverser class. Need to extract the reverse seq of the siRNA for alignment
//	output_alignseq = get_reverse(input_alignseq); 
	output_alignseq = rev.get_reverse(input_alignseq.substr(seed_len)); //reverse of the substring from position 8 to the end, seed binding removed.

	return output_alignseq;
}

string Aligner::extract_subject(string input_refseq){
	string output_refseq;
	
//	int siRNA_len = 21;
	int seed_len = 8;

//	output_refseq = input_refseq;
	output_refseq = input_refseq.substr(0, input_refseq.length()-seed_len); ; //remove the last 8nt from mRNA. Seed site removed.

	return output_refseq;
}


string Aligner::extract_subjectseed(string input_target, int seed_len){
	string seed =  input_target.substr(input_target.length()-seed_len);
	return seed;
}


